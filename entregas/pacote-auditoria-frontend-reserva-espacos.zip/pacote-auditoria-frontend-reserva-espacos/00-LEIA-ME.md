# Pacote de auditoria — Sistema de Reserva de Espaços (MPGO / UFG)

Entrega em resposta ao questionário de pré-redesign (23 itens). Contém o código-fonte, os contratos de API, as regras de negócio e o mapa de telas.

**Data:** 24/08/2026

---

## ⚠️ Comece por aqui: a premissa do questionário está errada

O questionário pede `package.json`, `components.json`, `tsconfig.json`, `vite.config`, `next.config`, `tailwind.config.js`, `src/pages/Spaces.tsx` e shadcn/ui.

**Nada disso existe.** Esta é uma aplicação **Django 5.2 server-rendered**: HTML gerado no servidor, interatividade via **HTMX**, estilo via **Tailwind CSS v4 + DaisyUI** com tema institucional `mpgo`. Sem React, sem TypeScript, sem bundler, sem Node.js em runtime. O projeto inteiro tem cerca de **15 linhas de JavaScript escritas à mão**.

Isso não invalida o redesign — mas muda o formato da entrega. **O que precisamos de volta são templates Django + classes DaisyUI, não componentes React.**
O anexo `06-EQUIVALENCIAS-SHADCN-DAISYUI.md` traduz cada componente e conceito citado no pedido para o equivalente daqui.

---

## O que tem neste pacote

| Arquivo / pasta | Conteúdo |
|---|---|
| **`01-AUDITORIA-RESPOSTAS.md`** | ⭐ **O documento principal.** Responde os 23 itens, um a um, apontando o arquivo correspondente |
| `02-REGRAS-DE-NEGOCIO.md` | O que o sistema faz e — principalmente — o que **não** faz. Separa regra de negócio de regra visual |
| `03-MAPA-DE-TELAS.md` | As 16 telas existentes: rota, view, template, blocos, estados e alvos HTMX |
| `05-FOTOS-DOS-ESPACOS-PROPOSTA.md` | Proposta técnica completa das fotos: modelo, migration, storage, validação, fallback, impacto arquivo a arquivo, checklist de aceite |
| `06-EQUIVALENCIAS-SHADCN-DAISYUI.md` | Tradução shadcn/React → DaisyUI/HTMX/Django, tokens de design e o cabeçalho a usar nos prompts de IA |
| `contratos-api/` | 8 exemplos reais de request/response, com as armadilhas de cada um |
| `screenshots/README.md` | Lista das 28 capturas a fazer: URL, conta, nome do arquivo e resolução |
| `codigo/` | O projeto: apps Django, templates, CSS, logo, configs, README, PRD e specs |

---

## Roteiro de leitura sugerido (≈45 min)

1. **`01-AUDITORIA-RESPOSTAS.md`**, itens 1 a 3 — entender a stack e a identidade visual. *(10 min)*
2. `codigo/assets/css/source.css` — o tema `mpgo` inteiro cabe em 200 linhas. É a fonte da identidade. *(5 min)*
3. `codigo/templates/spaces/space_list.html` + `_space_list_results.html` — a tela do mockup. *(5 min)*
4. **`02-REGRAS-DE-NEGOCIO.md`** — antes de desenhar qualquer coisa. *(10 min)*
5. `03-MAPA-DE-TELAS.md` — as 15 telas que não estavam no mockup. *(10 min)*
6. `05-FOTOS-DOS-ESPACOS-PROPOSTA.md` — o único item que obriga mudança de backend. *(5 min)*

---

## Os cinco pontos que mais impactam o redesign

**1. Não é React.** Entrega em templates Django + DaisyUI. Ver anexo 06.

**2. Vermelho é acento, não cor de fundo.** `#cd2340` só em CTA, item ativo e estado crítico. Está escrito como regra dentro do próprio CSS. A interface é deliberadamente branco/cinza/preto.

**3. Fotos dos espaços não existem — em nenhum nível.** Sem campo, sem upload, sem storage, sem Pillow. É a única parte do mockup que obriga migration + infraestrutura. Proposta pronta no anexo 05.

**4. O badge `● Disponível` no card não tem dado por trás.** Disponibilidade só é calculada **depois de escolher uma data**, por um endpoint separado. Ou muda a UX, ou é feature de backend. Ver auditoria, item 13.

**5. Existem funcionalidades entregues que não apareceram em nenhum mockup e não podem sumir:**
- **Busca com IA** em linguagem natural (LLM extrai capacidade, equipamentos e local, com ~60 sinônimos mapeados)
- **Consultar Normas** (`/assistente/`) — RAG sobre ~25 regulamentos públicos, com citação de fontes e histórico
- **Classificação de manutenção por IA** no painel admin
- **Check-in por QR Code** na porta da sala
- **Toggle ativar/desativar espaço** inline, sem sair da lista

---

## O que não pode ser quebrado

**Regras de negócio** — `codigo/reservations/validators.py` é fonte única. Models, serializers, services e forms todos delegam para lá. Não duplicar regra em template.

**A `ExclusionConstraint` do PostgreSQL** — impede reserva sobreposta no nível do banco, vencendo qualquer corrida. É por isso que PostgreSQL é obrigatório.

**Os alvos HTMX** — `#space-results`, `#availability-content`, `#reservation-actions`, `#occupancy-grid` e outros. Renomear um `id` desses **quebra a aplicação em silêncio**. Lista completa no anexo 03.

**O padrão página-ou-fragmento** — as views devolvem a página inteira ou só o pedaço, conforme o header `HX-Request`. É o que substitui o re-render do React.

**Os tokens do tema `mpgo`** — não há **nenhum** hex solto em template hoje. Manter assim.

---

## Coisas que já sabemos que estão erradas (corrigir junto é bem-vindo)

| Problema | Onde |
|---|---|
| Mensagens de erro de validação **em inglês** exibidas na UI pt-BR | `reservations/validators.py` — traduzir as mensagens, preservar os `code` |
| Fuso horário: o formulário grava o horário digitado **como UTC**, sem converter de UTC−3 | `reservations/views.py::_parse_datetime` + `TIME_ZONE` |
| Checkbox de equipamento marca por *substring* da querystring | `templates/spaces/space_list.html`, linha 107 |
| HTMX carregado de CDN externa (unpkg) — falha em rede institucional restrita | `templates/base.html`, linha 9 → servir de `static/` |
| Logo PNG de 249 KB carregado duas vezes por página | `static/img/logo.png` → SVG ou WebP |
| Status `completed` existe mas nada o define | `reservations/services.py` |
| `release_no_shows` precisa de cron externo, senão o pilar "liberação automática" não funciona | infraestrutura |

---

## Segurança do pacote

Removidos: `.env` (chaves reais do Groq), `.venv/`, `.git/`, `__pycache__/`, caches de teste, `db.sqlite3`.
Incluído apenas `.env.example` com valores fictícios. Removidos por volume: `uv.lock`, `data/normas/` (PDFs públicos) e `.agents/`/`.claude/`/`.cursor/`.

**Não há credencial nenhuma no pacote.**

---

## Como rodar o projeto

```bash
docker compose up -d
docker compose exec web python manage.py migrate
docker compose exec web python manage.py seed_data
# http://localhost:8000  ·  admin / reserva123
```

Detalhes completos em `codigo/README.md`. Para o assistente de normas funcionar é preciso também `GROQ_API_KEY` no `.env` e rodar `indexar_normas` (o corpus de PDFs não veio no pacote — peçam se precisarem).

---

## Dúvidas

Perguntem citando **o número do item** do questionário. As respostas estão organizadas nessa ordem em `01-AUDITORIA-RESPOSTAS.md`.
