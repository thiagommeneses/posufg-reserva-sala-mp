# Auditoria da aplicação — respostas aos 23 itens

**Projeto:** Sistema de Reserva de Espaços — MPGO / UFG
**Data:** 24/08/2026
**Escopo:** respostas ao questionário de pré-redesign, item por item, com os arquivos correspondentes no diretório `codigo/`.

---

## ⚠️ Leia isto antes de qualquer coisa

O questionário parte de uma premissa que **não corresponde à aplicação**. Ele pergunta por `package.json`, `components.json`, `tsconfig.json`, `vite.config`, `next.config`, `src/pages/Spaces.tsx`, shadcn/ui, React Hook Form, TanStack Query.

**Nada disso existe aqui.** Esta é uma aplicação **Django 5.2 server-rendered**: HTML gerado no servidor por Django Templates, interatividade parcial via **HTMX**, estilo via **Tailwind CSS v4 + DaisyUI** com um tema institucional customizado (`mpgo`). Não há build de JavaScript, não há bundler, não há Node.js no runtime, não há componentes React.

Isso **não é um problema** — mas muda a natureza da entrega:

| O que foi pedido | O que existe aqui | O que fazer |
|---|---|---|
| `package.json` | `pyproject.toml` | ver item 1 |
| `components.json` (shadcn) | não existe — DaisyUI é configurado por tema CSS | ver item 3 e o anexo `06-EQUIVALENCIAS-SHADCN-DAISYUI.md` |
| `tailwind.config.js` | não existe — Tailwind v4 configura no CSS (`assets/css/source.css`) | ver item 3 |
| `src/pages/Spaces.tsx` | `spaces/views.py` + `templates/spaces/space_list.html` | ver item 2 |
| `<SpaceCard />` | `templates/spaces/_space_list_results.html` (bloco `<article class="surface">`) | ver item 2 |
| `services/api.ts` | não existe no front — as views consultam o ORM direto; a API REST em `/api/v1/` existe para integrações | ver item 7 |
| Estado global (Redux/Zustand) | não existe — o estado vive na URL (querystring) e na sessão do Django | ver item 1 |

**Decisão do time:** manter a arquitetura Django + HTMX. O redesign deve ser entregue como **templates Django + classes DaisyUI/Tailwind**, não como componentes React. O anexo `06-EQUIVALENCIAS-SHADCN-DAISYUI.md` traduz cada componente shadcn citado no pedido para o equivalente disponível.

---

## 1. Stack real do projeto

| Camada | Tecnologia |
|---|---|
| Linguagem | Python ≥ 3.12 |
| Framework | Django 5.2 (`>=5.2,<5.3`) |
| API | Django REST Framework + `django-filter` |
| Docs de API | drf-yasg (Swagger em `/swagger/`, Redoc em `/redoc/`) |
| Templates | Django Templates (`templates/`, `DIRS=[BASE_DIR/"templates"]`, `APP_DIRS=True`) |
| Interatividade | **HTMX 2.0.4**, via CDN (`https://unpkg.com/htmx.org@2.0.4`) + `django-htmx` no middleware |
| CSS | **Tailwind CSS v4** via `django-tailwind-cli` 2.8.3 (binário standalone — **não usa Node.js**) |
| Biblioteca de componentes | **DaisyUI** (`TAILWIND_CLI_USE_DAISY_UI = True`) com tema custom `mpgo` |
| Ícones | **SVG inline**, sem biblioteca. Centralizados em `templates/partials/_icon.html` |
| Formulários | `django.forms` (ModelForm) — `accounts/forms.py`, `admin_dashboard/forms.py` |
| Date picker | **nativo do browser** — `<input type="date">` e `<input type="time">`. Não há biblioteca de calendário |
| Estado | Querystring + sessão Django. Sem store de cliente |
| Requisições | HTMX (`hx-get`/`hx-post`) + POST de formulário tradicional |
| Banco | **PostgreSQL 16** (obrigatório) com extensões `btree_gist` e `pgvector` |
| Autenticação | Sessão Django (`django.contrib.auth`), modelo `auth.User` padrão |
| LLM | Groq — modelo `openai/gpt-oss-120b` |
| Embeddings | fastembed (ONNX, local) — `paraphrase-multilingual-MiniLM-L12-v2`, 384 dimensões |
| Infra | Docker + Docker Compose |
| Qualidade | pytest (cobertura mínima 80%), ruff, pre-commit, commitizen |
| Gerenciador de pacotes | **uv** (`uv.lock`) |

**JavaScript escrito à mão no projeto:** ~15 linhas, num único lugar (`templates/spaces/_space_list_results.html`), só para logar detalhe técnico de erro da IA no console. Nada além disso.

**Arquivos enviados:** `codigo/pyproject.toml`, `codigo/config/settings.py`, `codigo/Dockerfile`, `codigo/docker-compose.yml`, `codigo/Makefile`, `codigo/.env.example`, `codigo/.pre-commit-config.yaml`.
`uv.lock` (445 KB) não foi incluído — se precisarem do lockfile exato, peçam.

---

## 2. Código da tela atual

A tela do screenshot ("Buscar espaços") é composta por:

```
templates/base.html                        ← <html>, <head>, tailwind_css, htmx
└── templates/base_user.html               ← layout drawer + sidebar do usuário
    └── templates/spaces/space_list.html   ← a página em si
        └── templates/spaces/_space_list_results.html  ← grid + cards (alvo do HTMX)
```

View: `spaces/views.py` → `SpaceListView` (linhas 78–168).

Ponto importante da arquitetura: **a mesma view serve a página inteira e o fragmento**. `get_template_names()` devolve `spaces/_space_list_results.html` quando o header `HX-Request: true` está presente, e `spaces/space_list.html` caso contrário. É esse padrão que substitui o "re-render do React" — qualquer redesign precisa preservá-lo.

Componentes correspondentes ao que foi pedido:

| Pedido | Onde está |
|---|---|
| Sidebar | `templates/base_user.html` (linhas 35–86) e `templates/base_admin.html` |
| Header | `templates/base_user.html` (linhas 8–29) — só aparece em `< lg`; no desktop a sidebar é fixa |
| SpaceCard | `templates/spaces/_space_list_results.html` (linhas 25–53) |
| Search (IA) | `templates/spaces/space_list.html` (linhas 12–36) |
| Filters | `templates/spaces/space_list.html` (linhas 38–118) |
| Layout | `templates/base.html` + `base_user.html` / `base_admin.html` |
| Button / Badge / Input | classes DaisyUI (`btn`, `badge`, `input input-bordered`) — não há wrapper de componente |
| Dialog / Modal | **não existe** nenhum modal na aplicação hoje |
| Calendar | **não existe** componente de calendário. Disponibilidade é uma grade de botões: `templates/spaces/_availability.html` |
| Stepper | `templates/components/_reservation_steps.html` (3 passos: Espaço / Horário / Confirmação) |
| Status badge | `templates/components/_reservation_status_badge.html` |

Todos os 36 templates foram enviados em `codigo/templates/`.

---

## 3. CSS e identidade visual atual

**Não existe `tailwind.config.js`.** O projeto usa Tailwind v4, que configura tudo em CSS. O arquivo é **`assets/css/source.css`** (enviado íntegro) — é a fonte da identidade visual.

O tema DaisyUI `mpgo` é definido lá, e é aplicado via `<html data-theme="mpgo">` em `base.html`.

### Cores oficiais (valores exatos, já em uso)

```css
@plugin "daisyui/theme" {
  name: "mpgo";
  default: true;
  color-scheme: light;

  --color-base-100: #ffffff;   /* superfície  */
  --color-base-200: #fafafa;   /* fundo da página */
  --color-base-300: #e8e8e8;   /* bordas */
  --color-base-content: #231f20;  /* preto institucional MPGO */

  --color-primary: #cd2340;    /* vermelho institucional MPGO */
  --color-primary-content: #ffffff;

  --color-secondary: #525252;
  --color-accent: #5c5c5c;
  --color-neutral: #231f20;
  --color-info: #52525b;
  --color-success: #15803d;
  --color-warning: #b45309;
  --color-error: #cd2340;

  --radius-selector: 0.5rem;
  --radius-field: 0.5rem;
  --radius-box: 0.5rem;
  --border: 1px;
}
```

| Token | Valor | Uso |
|---|---|---|
| Vermelho institucional | `#cd2340` | **somente** CTAs, item de menu ativo e estados críticos |
| Preto institucional | `#231f20` | texto principal |
| Cinza de borda | `#e8e8e8` | bordas de superfície |
| Fundo da página | `#fafafa` | `bg-base-200` |
| Verde (sucesso/disponível) | `#15803d` | |
| Âmbar (manutenção/atenção) | `#b45309` | |
| Raio de borda | `0.5rem` em tudo | |
| Espessura de borda | `1px` | |

**Regra de identidade que já está valendo e não deve ser quebrada:** *"vermelho só em CTAs/ativo/crítico"* — está escrito como comentário no próprio CSS. A interface é deliberadamente neutra (branco/cinza/preto) com o vermelho como acento.

### Tipografia

- **UI:** DM Sans (400/500/600/700) — carregada do Google Fonts.
- **Marca:** Barlow Condensed 700 (`.brand-font`) — usada só em "Reserva de Espaços" / "Admin".
- A fonte do manual de identidade do MPGO é **Swis721 BlkCn BT**, que é **proprietária**. Barlow Condensed é a substituta gratuita já adotada. Isso está documentado em comentário no `source.css`.

### Classes utilitárias próprias já existentes

Não são shadcn, mas cumprem o mesmo papel. **Reaproveitar, não recriar:**

| Classe | Papel |
|---|---|
| `.surface` | card/painel: fundo `base-100`, borda 1px `base-300`, raio `--radius-box`. **É o "Card" da aplicação.** |
| `.surface-muted` | idem, com fundo `base-200` |
| `.notice` | bloco de aviso |
| `.notice-error` / `.notice-success` / `.notice-warning` | variantes (usam `color-mix`) |
| `.nav-link` / `.nav-link-active` | navegação horizontal |
| `.sidebar-link` / `.sidebar-link-active` | item de sidebar — ativo = texto primary + fundo primary 6% + borda esquerda 2px primary |
| `.brand-font` | Barlow Condensed |
| `.brand-logo` | logo com proporção preservada |
| `.htmx-indicator` | spinner, escondido por padrão no CSS (não depende do htmx.js carregar) |

**Arquivos enviados:** `codigo/assets/css/source.css` (fonte) e `codigo/static/css/tailwind.css` (gerado — 142 KB, não editar à mão).

---

## 4. Logotipo e assets institucionais

- **Único asset:** `static/img/logo.png` — 249 KB. Enviado em `codigo/static/img/logo.png`.
- **Não existe versão SVG.**
- **Não temos** manual de identidade em arquivo, brasão vetorial nem ícones próprios neste repositório.
- **Fonte institucional:** Swis721 BlkCn BT — proprietária, não distribuída com o projeto. Substituta em uso: Barlow Condensed.
- **Restrições de marca:** é logo do Ministério Público do Estado de Goiás. Não redesenhar, não recolorir, não recortar. O `alt` correto já usado é `"Logo do Ministério Público do Estado de Goiás"`.

**Pedido concreto de vocês para nós:** se o redesign precisar de logo vetorial, digam — providenciamos com a comunicação do MPGO. O PNG de 249 KB é grande demais para ser servido em duas instâncias por página; converter para SVG (ou pelo menos WebP otimizado) é um ganho fácil e já vale como item do backlog.

### Tokens sugeridos (item 4 do pedido)

Os tokens que vocês propuseram já têm equivalente direto no tema:

| Token proposto | Equivalente atual |
|---|---|
| `--brand-primary` | `--color-primary` (`#cd2340`) |
| `--brand-primary-hover` | não existe — hoje é `color-mix(in oklab, var(--color-primary) 10%, white)` para fundos. **Criar** |
| `--brand-primary-subtle` | não existe explicitamente — hoje é `color-mix(... 6%, white)`, repetido em 4 lugares. **Criar** |
| `--brand-border` | `--color-base-300` |
| `--brand-sidebar` | `--color-base-100` |

**Concordamos com a crítica implícita:** o padrão `color-mix(in oklab, var(--color-primary) 6%, white)` aparece repetido em `.nav-link-active`, `.nav-link-active:hover`, `.sidebar-link-active` e `.sidebar-link-active:hover`. Deve virar token. O que **não** acontece hoje (e não deve passar a acontecer) é hex solto em template: não há nenhum `bg-[#cd2340]` no código — pode conferir.

---

## 5. Estrutura atual da Sidebar

Existem **duas** sidebars distintas, não uma com permissões:

**`templates/base_user.html`** — sidebar do usuário (largura `w-60`):

```
[logo] Reserva de Espaços
       Olá, {{ username }}

ATALHOS
  ├ Espaços            → /spaces/
  ├ Minhas Reservas    → /reservations/
  └ Consultar Normas   → /assistente/

ADMINISTRAÇÃO          ← só se request.user.is_staff
  └ Painel Admin       → /admin-dashboard/

─────────────────
  Sair (POST /accounts/logout/)
```

**`templates/base_admin.html`** — sidebar do painel admin (largura `w-64`):

```
[logo] Admin
       Olá, {{ username }}

  Dashboard   → /admin-dashboard/
  Espaços     → /admin-dashboard/spaces/
  Reservas    → /admin-dashboard/reservations/
  Manutenção  → /admin-dashboard/maintenance/
  Usuários    → /admin-dashboard/users/

─────────────────
  Voltar ao Site → /
```

Respondendo diretamente:

- **Quais opções existem hoje:** as listadas acima. Nada além.
- **Usuário comum vê:** Espaços, Minhas Reservas, Consultar Normas, Sair.
- **Admin vê:** tudo do usuário + a seção "Administração" com Painel Admin; e dentro do painel, a sidebar admin com 5 itens.
- **Outros perfis:** não existem. Só `is_staff` true/false (ver item 18).
- **O menu vem do backend?** Não. É **HTML fixo no template**, com `{% if request.user.is_staff %}` controlando a seção admin. O item ativo é detectado por `{% if "/spaces/" in request.path %}`.
- Ambas as sidebars usam o padrão DaisyUI `drawer lg:drawer-open`: fixa em ≥1024px, gaveta com overlay abaixo disso.

### Sobre a sidebar que vocês propuseram

A proposta de vocês inclui itens que **não existem** e criariam telas mortas:

| Item proposto | Situação |
|---|---|
| Dashboard | existe só para admin |
| Nova Reserva | existe como rota (`/reservations/new/`), mas hoje é sempre alcançada a partir de um espaço + horário. Um link direto no menu levaria a um formulário sem espaço selecionado — hoje isso redireciona de volta para `/spaces/` com erro |
| Minhas Reservas | ✅ existe |
| Calendário | **não existe** — não há visão de calendário em lugar nenhum |
| Espaços › Salas de Reunião / Auditório / Espaços Compartilhados / Equipamentos | **não existe** — `Space` não tem campo "tipo" (ver item 6). Essa subdivisão exige mudança de modelo |
| Painel Administrativo | ✅ existe |
| Relatórios | **não existe** |
| Configurações | **não existe** |
| Ajuda | **não existe** |

Faltou na proposta de vocês: **Consultar Normas** (`/assistente/`), que é um assistente RAG sobre 25+ regulamentos de uso de espaços de instituições públicas. É uma funcionalidade entregue e diferenciada — não pode sumir do menu.

---

## 6. Modelo atual de um espaço

Arquivo: `spaces/models.py`. **Este é o modelo verdadeiro, sem simplificação:**

```python
class Space(models.Model):
    name        = models.CharField(max_length=255)
    description = models.TextField(blank=True, null=True)
    capacity    = models.PositiveIntegerField()
    location    = models.CharField(max_length=255)   # texto livre, ex.: "2º andar, Bloco A"
    is_active   = models.BooleanField(default=True)
    created_at  = models.DateTimeField(auto_now_add=True)
    updated_at  = models.DateTimeField(auto_now=True)

class Attribute(models.Model):
    name = models.CharField(max_length=100, unique=True)

class SpaceAttribute(models.Model):     # tabela de junção (through)
    space     = FK(Space,     related_name="space_attributes")
    attribute = FK(Attribute, related_name="space_attributes")
    # UniqueConstraint(space, attribute)
```

Ou seja, o `Space` tem **7 campos e nada mais**. Confirmando explicitamente o que vocês perguntaram:

- ❌ **não existe** `imageUrl`, `coverImageUrl`, `images` — nenhum campo de imagem
- ❌ **não existe** campo de tipo/categoria do espaço
- ❌ **não existe** "descrição curta" separada
- ❌ **não existe** `requires_approval`
- ❌ **não existe** `features` separado de `attributes`
- ❌ **não existe** prédio/andar/bloco estruturados — `location` é uma string livre

**Arquivos enviados:** `codigo/spaces/models.py`, `codigo/spaces/migrations/0001_initial.py`, `codigo/spaces/serializers.py`, `codigo/spaces/admin.py`.

---

## 7. Endpoint que retorna os espaços

Existem **dois caminhos** para os mesmos dados — é importante não confundir:

### a) Interface web (o que a tela do screenshot usa)

**Não há chamada HTTP a uma API.** A view `SpaceListView` consulta o ORM diretamente e renderiza HTML. O HTMX pede o **fragmento HTML**, não JSON:

```html
<form hx-get="{% url 'space_list' %}" hx-target="#space-results" hx-indicator="#loading-indicator">
```

Resposta: `text/html` com o conteúdo de `_space_list_results.html`.

### b) API REST (para integrações e o QR Code de check-in)

`GET /api/v1/spaces/` — `spaces/views.py` → `SpaceViewSet` + `SpaceSerializer`.

Resposta real (exemplo com os dados de seed):

```json
[
  {
    "id": 1,
    "name": "Sala de Reunião Alfa",
    "description": null,
    "capacity": 8,
    "location": "2º andar, Bloco A",
    "is_active": true,
    "created_at": "2026-08-24T13:02:11.482913Z",
    "updated_at": "2026-08-24T13:02:11.482913Z",
    "attributes": ["Ar-condicionado", "TV", "Videoconferência", "Wi-Fi"]
  }
]
```

Confrontando com a lista de campos que vocês esperavam:

| Campo esperado | Existe? |
|---|---|
| `id` | ✅ |
| `nome` | ✅ `name` |
| `descrição` | ✅ `description` (nullable, e **na prática está null** — o seed não preenche) |
| `capacidade` | ✅ `capacity` |
| `localização` | ✅ `location` (string livre) |
| `tipo` | ❌ |
| `recursos` | ✅ `attributes` — **lista de strings**, não objetos |
| `status` | ⚠️ só `is_active` (bool). Disponibilidade é calculada à parte — ver item 13 |
| `disponibilidade` | ❌ não vem no `/spaces/`. Endpoint separado: `GET /api/v1/spaces/{id}/availability/?date=YYYY-MM-DD` |
| `imagem` | ❌ |

Todos os contratos de API, com exemplos completos, estão em `contratos-api/`.

**Isso responde à pergunta "até onde a mudança é apenas frontend":** capa/galeria de fotos, tipo de espaço e badge de disponibilidade no card **exigem backend**. Detalhamento no item 8 e no anexo `05-FOTOS-DOS-ESPACOS-PROPOSTA.md`.

---

## 8. Fotos dos espaços

**Confirmado: não existe absolutamente nada de imagem no sistema hoje.** Nem campo, nem upload, nem storage, nem `MEDIA_ROOT`, nem `MEDIA_URL` no `settings.py`.

Concordamos com a abordagem de vocês (entidade real, não `<img src="/sala1.jpg">`). A proposta completa — modelo de dados, migration, storage, validação, thumbnails, fallback, permissões, cache e impacto em cada tela — está no anexo **`05-FOTOS-DOS-ESPACOS-PROPOSTA.md`**.

Resumo do impacto: **1 migration**, **1 dependência nova (Pillow)**, **1 configuração de storage**, **2 telas admin alteradas**, **3 templates de card alterados**, **1 campo novo no serializer**. Nenhuma regra de negócio é tocada.

---

## 9. Storage de arquivos

**Não existe upload de arquivo de usuário no sistema.** Nenhum. Respondendo à sua lista:

- filesystem: ❌ (não configurado para uploads)
- PostgreSQL: usado só para dados relacionais + vetores
- MinIO / S3 / Azure Blob / GCS / Supabase: ❌ nenhum

O único fluxo de arquivo existente é **de leitura, no servidor**: o comando `python manage.py baixar_normas` baixa PDFs/HTMLs de regulamentos públicos para `data/normas/`, e `indexar_normas` extrai o texto e grava embeddings no Postgres (pgvector). Isso é pipeline de ingestão, não upload de usuário — não serve de base para as fotos.

**Contexto que importa para a decisão:** é ambiente institucional (MPGO), o deploy é Docker Compose. A recomendação — e a justificativa — está no anexo `05-FOTOS-DOS-ESPACOS-PROPOSTA.md`, seção "Storage".

---

## 10. Tela administrativa de cadastro de espaço

**Existe.** Duas, na verdade:

1. **Painel admin customizado** (o que os administradores usam):
   - `/admin-dashboard/spaces/` — lista → `admin_dashboard/views.py::AdminSpaceListView` + `templates/admin_dashboard/space_list.html`
   - `/admin-dashboard/spaces/new/` — criar → `AdminSpaceCreateView`
   - `/admin-dashboard/spaces/<pk>/` — editar → `AdminSpaceUpdateView`
   - `/admin-dashboard/spaces/<pk>/toggle/` — ativar/desativar inline via HTMX (`PATCH`), devolve só o badge
   - Form: `admin_dashboard/forms.py::SpaceForm`
   - Template: `templates/admin_dashboard/space_form.html`

2. **Django Admin padrão** em `/admin/` (`spaces/admin.py`) — existe mas não é o caminho principal.

**Campos do formulário hoje** (`SpaceForm.Meta.fields`):

```
name         → input text
description  → textarea (3 linhas)
capacity     → input number
location     → input text
is_active    → checkbox
attributes   → CheckboxSelectMultiple (chips com borda, renderizados manualmente no template)
```

Detalhe de implementação relevante: o form renderiza os campos com `{% for field in form %}` genérico, **exceto** `attributes`, que tem tratamento especial (chips). Qualquer redesign do form precisa preservar esse `if`.

O `SpaceForm.save()` sincroniza a tabela `SpaceAttribute` manualmente (diff entre selecionados e atuais) — não é `ManyToManyField` com `.set()`.

Os campos que vocês querem acrescentar (imagem de capa, galeria, tipo, descrição curta, características, requer aprovação) **não existem** e cada um tem custo de backend. Ver anexo `03-MAPA-DE-TELAS.md`, seção "custo por campo novo".

---

## 11. Fluxo atual de reserva

O fluxo real, em 3 passos (não 4):

```
1. /spaces/                                  → busca (IA ou filtros) e escolhe um espaço
2. /spaces/{id}/?date=YYYY-MM-DD             → escolhe a data, vê a grade de horários,
                                               clica num slot LIVRE
3. /reservations/new/?space={id}&start={ISO} → confirma data/início/fim
   POST → /reservations/new/                 → cria e redireciona para /reservations/{id}/
```

O stepper (`templates/components/_reservation_steps.html`) reflete exatamente isso: **1. Espaço / 2. Horário / 3. Confirmação**.

Pré-preenchimento: ao clicar num slot livre, `ReservationCreateView.get()` lê `?start=` (ISO 8601), preenche data e hora de início, e propõe **fim = início + 1 hora**.

### Campos do formulário de reserva

O formulário tem **exatamente três campos**, todos obrigatórios:

| Campo | Widget | Obrigatório |
|---|---|---|
| `date` | `<input type="date">` | ✅ |
| `start_time` | `<input type="time">` | ✅ |
| `end_time` | `<input type="time">` | ✅ |
| `space` | `<input type="hidden">` (vem da URL) | ✅ |

Confrontando com a sua lista: **não existem** Título, Descrição, Quantidade de pessoas, Responsável, Departamento, Equipamentos da reserva, nem Observações. Não há campo livre nenhum. Adicionar qualquer um deles = migration + alteração de serializer + alteração de validators.

Consequência de design: como não há "finalidade" nem "título", a listagem de reservas mostra apenas **nome do espaço + horário + status**. Um card de reserva mais rico no redesign vai parecer vazio até que se decida adicionar campos.

Observação técnica importante: `date` + `start_time` são combinados e marcados como **UTC direto** (`dt.replace(tzinfo=datetime.UTC)`), não convertidos do fuso local. `TIME_ZONE = "UTC"` no settings. Isso é um bug latente para usuários em Goiás (UTC−3) — não é problema de UI, mas o redesign vai expor mais o sintoma se mostrar horários formatados.

---

## 12. Regras de negócio

Resposta curta e honesta: **quase nenhuma das regras que vocês listaram existe.** A lógica está centralizada em `reservations/validators.py` (que é a fonte única — models, serializers, services e forms do admin todos delegam para lá) e `reservations/services.py`.

| Pergunta de vocês | Resposta real |
|---|---|
| Usuário pode reservar no mesmo dia? | **Sim.** Não há restrição |
| Antecedência mínima/máxima? | **Nenhuma.** Nem sequer há validação de "não reservar no passado" |
| Duração máxima? | **Nenhuma.** Uma reserva de 30 dias passa |
| Reserva recorrente? | **Não existe** |
| Reservas precisam de aprovação? | **Não.** Nascem `confirmed` |
| Algumas salas exigem aprovação? | **Não.** Não há esse campo |
| Usuário pode cancelar? | **Sim**, a própria, se estiver em `confirmed` ou `checked_in` |
| Até quanto tempo antes? | **Sem limite.** Pode cancelar até o fim do horário |
| Reservas simultâneas no mesmo espaço? | **Não** — bloqueadas em 3 camadas (ver abaixo) |
| Nº de convidados influencia a sala? | **Não.** Não há campo de convidados |
| Capacidade pode ser ultrapassada? | **N/A** — não se informa quantas pessoas vão |
| Equipamentos são reserváveis? | **Não.** São atributos do espaço (ver item 16) |
| Feriados bloqueiam? | **Não.** Não há calendário de feriados |
| Fim de semana é permitido? | **Sim.** Sem restrição |
| Horário de funcionamento? | **Não existe.** A grade de disponibilidade vai de 00:00 a 24:00 |

**As regras que de fato existem** (essas sim, não podem ser quebradas):

1. **Sem sobreposição** no mesmo espaço, para status `confirmed` e `checked_in`. Garantido em 3 níveis: `validators.py`, `services.create_reservation()` e uma `ExclusionConstraint` PostgreSQL (`btree_gist` + `tstzrange`) que vence qualquer corrida.
2. **`end_time` estritamente maior que `start_time`.**
3. **Espaço inativo (`is_active=False`) não aceita nova reserva** — mas uma reserva já existente continua reagendável (`require_active_space=False` no reschedule), por decisão explícita.
4. **Bloqueio de manutenção impede reserva** no intervalo; e criar manutenção sobre reserva ativa é recusado.
5. **Check-in:** só de reserva `confirmed`, e só na janela **de 15 min antes do início até o horário de fim**.
6. **No-show automático:** reserva `confirmed` cujo `start_time + 15 min` já passou sem check-in vira `no_show`. Comando: `python manage.py release_no_shows`. **Precisa de cron/scheduler externo — não há agendador embutido.**
7. **Propriedade:** só o dono cancela/reagenda/faz check-in da própria reserva (`OwnershipError`). Admin pode cancelar qualquer uma (`admin_cancel_reservation`).

Detalhamento completo, com código de erro e mensagem de cada regra, no anexo **`02-REGRAS-DE-NEGOCIO.md`**.

---

## 13. Disponibilidade

Aqui a sua intuição estava certa: **hoje não faz sentido calcular "Disponível / Poucos horários / Indisponível" antes de escolher a data.**

O que existe:

- `GET /api/v1/spaces/{id}/availability/?date=YYYY-MM-DD` → `reservations/services.py::get_availability_for_date()`
- Retorna, **para uma data específica**, os intervalos `occupied` (com `type: "reservation" | "maintenance"`) e `free`, já mesclados e ordenados.
- A janela é o dia inteiro em UTC: 00:00 → 24:00. Não há horário comercial.
- Renderizado em `templates/spaces/_availability.html` como grade de botões, com legenda de 3 cores:

| Estado | Cor atual | Semântica |
|---|---|---|
| Disponível | `success` (`#15803d`), botão outline clicável | slot livre → leva a `/reservations/new/` |
| Reservado | `base-300`, botão desabilitado | há reserva ativa |
| Manutenção | `warning` (`#b45309`), botão desabilitado | há bloqueio de manutenção |

**Portanto:** o badge `● Disponível` no card da listagem (`/spaces/`), como está no mockup, **não tem dado por trás hoje**. Duas saídas, escolham uma:

- **(A) Mudar a UX:** o card não mostra estado; o estado só aparece depois de escolher a data. É o comportamento atual, é honesto e é custo zero.
- **(B) Implementar de verdade:** o card ganha um badge calculado *para hoje* (ou para a data já escolhida em um filtro de data na listagem). Custo: um método agregado que roda `get_availability_for_date` para N espaços — hoje isso seria **N+1 queries**. Precisa de uma query agregada nova. É trabalho de backend, não de frontend.

Se for (B), definam a semântica; nossa sugestão, alinhada ao que vocês propuseram:

```
Disponível      → há ≥ 1 slot livre de pelo menos 30 min no dia
Poucos horários → total de tempo livre < 30% da janela considerada
Indisponível    → nenhum slot livre (ou espaço em manutenção / is_active=False)
```

Existe também `GET /api/v1/admin/occupancy/?date=` (admin) que devolve todos os espaços com reservas e manutenções do dia — e o dashboard admin (`/admin-dashboard/`) já classifica cada espaço **no instante atual** em `free` / `occupied` / `maintenance`. Se quiserem "estado agora" no card, essa lógica já existe em `admin_dashboard/views.py::AdminDashboardView` (linhas 44–102) e pode ser extraída.

---

## 14. Busca com IA

Isso existe e funciona. **Não simplifiquem para busca convencional** — concordamos com vocês.

### Como funciona

`spaces/views.py::SpaceListView._filter_by_ai_query()` → `ai_assistant/services.py::extract_room_search_filters(query)`.

1. O texto do usuário vai para o Groq (`openai/gpt-oss-120b`) com um system prompt que exige **JSON puro** no formato:

```json
{
  "min_capacity": 8,
  "max_capacity": null,
  "attributes": ["Videoconferência"],
  "location": null,
  "summary": "Sala para pelo menos 8 pessoas com videoconferência."
}
```

2. O prompt força os `attributes` a saírem **exclusivamente do catálogo** de 7 atributos (`core/seeds/attributes.py`), e ensina a distinguir piso (`min_capacity`: "para 8 pessoas", "pelo menos 8") de teto (`max_capacity`: "até 4 pessoas", "no máximo 4").
3. Há ainda uma camada determinística de sinônimos em Python (`ATTRIBUTE_SYNONYMS`, ~60 entradas): "internet"/"wifi"/"rede" → Wi-Fi; "datashow"/"slides" → Projetor; "meet"/"zoom"/"teams"/"call" → Videoconferência; "lousa" → Quadro branco; "ac"/"clima" → Ar-condicionado. Ela normaliza acentos e corrige o que o LLM inventar fora do catálogo.
4. Os filtros viram queryset e o `summary` é devolvido para a UI.

### Como aparece na tela hoje

- Card "Busca com IA" no topo de `/spaces/`, com `hx-get` e spinner (`#ai-loading-indicator`).
- **Sucesso:** faixa `.notice` com **"Entendi: {{ ai_summary }}"** acima dos resultados.
- **Erro:** faixa `.notice-error` com mensagem amigável (`exc.user_message`); o detalhe técnico vai para o `console.warn` sob a tag `[busca-salas-ia]`.
- Erros tratados: sem chave configurada, chave inválida, rate limit (com tempo de espera extraído da mensagem do Groq), falha de conexão, JSON inválido.

### Endpoint equivalente

`POST /api/v1/ai/room-search/` — `{"query": "..."}` → `{summary, filters, results[]}`, máximo 10 resultados. `502` se o provedor falhar. Exemplo completo em `contratos-api/`.

### O que preservar no redesign

- O `summary` ("Entendi: ...") — é o que dá confiança ao usuário de que a IA entendeu.
- O tratamento de erro em faixa (não pode "sumir" a lista silenciosamente).
- O spinner ligado ao `hx-indicator`, **não** um estado de loading em JS.
- O detalhe técnico no console (é como o suporte diagnostica).

A UX que vocês propuseram (um campo único "Descreva o espaço que você precisa" + chips dos filtros aplicados) é uma **melhoria real** e é compatível: os filtros extraídos já vêm estruturados no dict `filters` — basta renderizá-los como chips.

**Terceira funcionalidade de IA que não estava no radar de vocês:** `/assistente/` — assistente RAG que responde perguntas sobre normas de uso de espaços, com citação de fontes. Templates `knowledge/assistant.html` e `knowledge/_assistant_answer.html`. Também não pode sumir.

---

## 15. Filtros atuais

Todos em `templates/spaces/space_list.html` (linhas 38–118), processados em `SpaceListView.get_queryset()`.

| Filtro | Widget | Query param | Lógica no backend |
|---|---|---|---|
| Capacidade mínima | `<input type="number">` | `min_capacity` | `capacity__gte` |
| Capacidade máxima | `<input type="number">` | `max_capacity` | `capacity__lte` |
| Localização | `<input type="text">` | `location` | `location__icontains` |
| Equipamentos | 7 checkboxes | `attributes` (lista) | **AND** — um `.filter()` encadeado por atributo, depois `.distinct()` |

Os 7 equipamentos são carregados do banco (`Attribute.objects.order_by("name")`), não hardcoded no template: Ar-condicionado, Projetor, Quadro branco, TV, Videoconferência, Webcam, Wi-Fi.

Comportamento HTMX relevante: os **checkboxes disparam a busca sozinhos** (`hx-get` + `hx-include="closest form"`), sem precisar clicar em Filtrar. Os inputs de texto/número só aplicam ao submeter.

⚠️ **Bug conhecido, para o redesign não replicar:** o "checked" dos checkboxes é decidido por `{% if attr.name in selected_attributes %}`, onde `selected_attributes` é a **string crua** da querystring. Isso faz `"TV"` marcar-se sozinho quando o filtro selecionado é `"TV, Videoconferência"` — mas também faria `"Wi-Fi"` casar dentro de uma string maior por substring. Deve virar lista de verdade.

### Sobre a proposta de vocês

Concordamos com a substituição do bloco de filtros permanente por `Buscar espaço... [Filtros]` + chips de filtros ativos. Equivalências (detalhes no anexo 06):

| shadcn | DaisyUI / HTMX |
|---|---|
| `Popover` | `dropdown` |
| `Command` | não tem equivalente — construir com `input` + lista filtrada por HTMX |
| `Checkbox` | `checkbox` |
| `Badge` (chip removível) | `badge` + botão `×` com `hx-get` |
| `Button` | `btn` |
| `Sheet` (mobile) | `drawer` — já usado nas sidebars |

---

## 16. Equipamentos

**São atributos simples, não entidades reserváveis.** Sem quantidade, sem estado, sem individualização:

```python
class Attribute(models.Model):
    name = models.CharField(max_length=100, unique=True)   # é só isso
```

Ou seja, está mais perto de `space.hasProjector = true` do que de `[{id: 17, type: "PROJECTOR", quantity: 2}]`. A tabela `SpaceAttribute` só liga espaço↔atributo, com `UniqueConstraint`.

Na API, `attributes` é uma **lista de strings**, não de objetos:

```json
"attributes": ["Ar-condicionado", "TV", "Videoconferência", "Wi-Fi"]
```

**Portanto: nenhum equipamento é reservável individualmente.** A etapa 3 do fluxo não precisa considerar isso. Se algum dia precisar, é uma mudança grande (quantidade, disponibilidade por equipamento, conflito de equipamento em paralelo ao conflito de sala) — e não deve entrar no escopo de um redesign visual.

Os 7 atributos vêm do seed (`core/seeds/attributes.py`), mas são dados de banco: um admin pode criar outros pelo `/admin/`. **Não hardcodem a lista de 7 no HTML** — o template já itera sobre o queryset, mantenham assim.

---

## 17. Autenticação

- **Mecanismo:** sessão Django padrão (`django.contrib.sessions` + `django.contrib.auth`). Cookie de sessão, CSRF token em todo POST.
- **Sem JWT, sem Keycloak, sem Azure AD/Entra, sem LDAP, sem OAuth.**
- **Modelo de usuário:** `django.contrib.auth.models.User` **padrão, sem customização**. `accounts/models.py` está literalmente vazio.
- Login: `accounts/views.py::login_view` usando `AuthenticationForm`. Redireciona por perfil: staff → `/admin-dashboard/`, comum → `/spaces/`.
- Registro aberto em `/accounts/register/` — cria sempre usuário comum.
- API: `DEFAULT_PERMISSION_CLASSES = [IsAuthenticated]`, autenticada pela **mesma sessão** (`rest_framework.urls` incluído para login navegável). Não há emissão de token.

### Dados disponíveis do usuário

Isto responde diretamente à sua pergunta sobre o card inferior da sidebar:

```python
user.username     # ✅ é o que a sidebar mostra hoje: "Olá, {{ request.user.username }}"
user.email        # ✅ existe (coletado no registro)
user.first_name   # ⚠️ existe no modelo mas NUNCA é preenchido
user.last_name    # ⚠️ idem
user.is_staff     # ✅
user.is_active    # ✅
```

❌ **Não existe `department`.** ❌ Não existe `role` além de `is_staff`. ❌ Não existe foto/avatar. ❌ Não existe nome completo utilizável.

O mockup de vocês, com `{name: "Ana Maria", department: "Departamento Jurídico", role: "USER"}`, **não é implementável hoje**. Para ter isso: criar um `Profile` (OneToOne com `User`) ou trocar para `AUTH_USER_MODEL` custom — a segunda opção é cara em projeto já migrado. Recomendamos `Profile`, e nesse caso decidam se `department` é texto livre ou FK para uma tabela de setores.

Enquanto não existir: o card da sidebar deve mostrar `username` e, no máximo, "Administrador"/"Usuário" derivado de `is_staff`.

---

## 18. Perfis e permissões

**Só existem dois perfis, e eles são o booleano `is_staff`.** Não há grupos, não há `Permission` customizada, não há "Gestor do espaço", "Recepção" ou "Facilities".

Mecanismo: `admin_dashboard/views.py::StaffRequiredMixin` (`UserPassesTestMixin` testando `request.user.is_staff`) para as telas, e `permissions.IsAdminUser` no DRF.

| Função | Usuário | Admin (`is_staff`) |
|---|---|---|
| Buscar espaços / ver disponibilidade | ✓ | ✓ |
| Busca com IA | ✓ | ✓ |
| Consultar normas (`/assistente/`) | ✓ | ✓ |
| Criar reserva | ✓ | ✓ |
| Ver **as próprias** reservas | ✓ | ✓ |
| Cancelar a própria reserva | ✓ | ✓ |
| Reagendar a própria reserva | ✓ | ✓ |
| Check-in na própria reserva | ✓ | ✓ |
| Ver **todas** as reservas | — | ✓ |
| Cancelar reserva de terceiro | — | ✓ |
| Criar / editar espaço | — | ✓ |
| Ativar / desativar espaço | — | ✓ |
| Criar / remover bloqueio de manutenção | — | ✓ |
| Classificar motivo de manutenção com IA | — | ✓ |
| Dashboard de ocupação | — | ✓ |
| Criar / editar / remover usuário | — | ✓ |
| Promover usuário a admin | — | ✓ |
| Relatórios | — | **não existe** |
| Aprovar reserva | — | **não existe** (reservas não passam por aprovação) |

Regra de segurança implementada: um admin **não pode remover a própria conta** (`AdminUserDeleteView`).

---

## 19. Responsividade

O que está implementado hoje (breakpoints Tailwind padrão):

| Breakpoint | O que muda |
|---|---|
| `< 640px` (base) | 1 coluna de cards; filtros empilhados; sidebar em gaveta |
| `≥ 640px` (`sm`) | filtros em 2 colunas; padding maior; grade de horários em 2 colunas |
| `≥ 768px` (`md`) | 2 colunas de cards; grade de horários em 3 colunas |
| `≥ 1024px` (`lg`) | **sidebar fixa** (`lg:drawer-open`), header mobile some; 3 colunas de cards; filtros em 4 colunas; grade de horários em 4 colunas |
| Container | `max-w-6xl` (1152px) na área do usuário; `max-w-7xl` (1280px) no admin |

O layout **já é mobile-first e funcional em celular** — o check-in por QR Code na porta da sala pressupõe uso em celular, então mobile não é opcional.

Sobre os dispositivos reais: essa informação nós **não temos medida** (não há analytics instalado). O que sabemos do contexto: ambiente institucional MPGO, majoritariamente desktop 1920×1080 e notebooks 1366×768; celular é caminho obrigatório para o check-in.

Os breakpoints que vocês recomendaram (≥1440 / 1024–1439 / 768–1023 / <768) são compatíveis com o que existe, exceto o ≥1440 — hoje o container **para** em 1152px e centraliza. Se quiserem aproveitar telas grandes, é uma decisão a tomar explicitamente (4ª coluna de cards? sidebar mais larga?).

---

## 20. Navegadores suportados

Não há política formal escrita. Realidade do ambiente institucional: **Edge e Chrome** dominam; Firefox eventual; Safari praticamente ausente (não há macOS/iOS corporativo relevante).

O que já é assumido pelo código atual e vale confirmar:

- `<input type="date">` e `<input type="time">` **nativos** — renderização e formato variam bastante entre Chrome/Edge e Firefox. Se o redesign quiser aparência consistente, precisa de um date picker próprio (aí sim entra JS, e é decisão nova).
- `color-mix(in oklab, ...)` no CSS — exige Chrome/Edge 111+, Firefox 113+, Safari 16.2+. Sem fallback hoje.
- HTMX 2.x carregado de **CDN externa (unpkg)** — em rede institucional com egress restrito isso pode falhar e a aplicação perde toda a interatividade. **Recomendação:** servir o htmx localmente a partir de `static/`. Vale como item do backlog independente do redesign.

---

## 21. Screenshots das outras telas

Descrição estrutural de cada tela está no anexo **`03-MAPA-DE-TELAS.md`** — bloco a bloco, com template, view e estados.

As capturas em si **serão anexadas em `screenshots/`**. A lista exata do que capturar, com URL, nome de arquivo e resolução, está em **`screenshots/README.md`**.

---

## 22. Projeto enviado

Enviado em `codigo/`. Frontend e backend são o mesmo projeto Django — não há separação.

**Removido, conforme pedido:** `.venv/`, `.git/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.coverage`, `db.sqlite3`.
**Removido por segurança:** `.env` (chaves reais do Groq). Enviado apenas `.env.example` com valores fictícios.
**Removido por volume:** `uv.lock` (445 KB), `data/normas/` (~30 PDFs de regulamentos públicos, dezenas de MB) e `.agents/` `.claude/` `.cursor/` (skills de ferramenta de desenvolvimento, irrelevantes).

**Não há segredo nenhum no pacote.** Conferido arquivo por arquivo.

---

## 23. Arquivos mínimos (checklist dos 10 itens)

| # | Pedido | Onde está no pacote |
|---|---|---|
| 1 | `package.json` | `codigo/pyproject.toml` (equivalente) |
| 2 | `components.json` | não existe — ver item 3 desta auditoria |
| 3 | `globals.css` / `index.css` | `codigo/assets/css/source.css` (fonte) + `codigo/static/css/tailwind.css` (gerado) |
| 4 | Código da página do screenshot | `codigo/templates/spaces/space_list.html` + `codigo/templates/spaces/_space_list_results.html` + `codigo/spaces/views.py` |
| 5 | Código da Sidebar | `codigo/templates/base_user.html` e `codigo/templates/base_admin.html` |
| 6 | Card atual dos espaços | `codigo/templates/spaces/_space_list_results.html`, linhas 25–53 |
| 7 | Service que busca os espaços | `codigo/spaces/views.py` (web, via ORM) e `codigo/spaces/serializers.py` (API) |
| 8 | JSON de exemplo da API | `contratos-api/*.json` |
| 9 | Model / DTO / schema de Space | `codigo/spaces/models.py`, `codigo/spaces/migrations/0001_initial.py`, `codigo/spaces/serializers.py` |
| 10 | Tela admin de cadastro/edição | `codigo/templates/admin_dashboard/space_form.html` + `codigo/admin_dashboard/forms.py` + `codigo/admin_dashboard/views.py` |

---

## Separação que pedimos que vocês respeitem na entrega

Vocês propuseram separar UI / frontend / backend / opcional. Reforçando o que **não é opcional** e não pode ser perdido no redesign:

**Regras de negócio (não tocar):**
- `reservations/validators.py` é fonte única — não duplicar regra em template ou view.
- A `ExclusionConstraint` do PostgreSQL é a última linha de defesa contra corrida. Não remover.
- Janela de check-in de 15 min antes; no-show em 15 min depois.
- Só o dono cancela/reagenda/faz check-in.

**Funcionalidades que não apareceram no mockup e devem sobreviver:**
- Busca com IA (com o "Entendi: ...")
- Assistente de normas (`/assistente/`)
- Classificação de manutenção por IA (admin)
- Toggle ativar/desativar espaço inline via HTMX
- Check-in por QR Code

**Padrão de arquitetura a preservar:**
- View única servindo página + fragmento via `HX-Request`.
- Alvos HTMX (`#space-results`, `#ai-loading-indicator`, `#loading-indicator`) — se mudarem o `id`, a interatividade quebra silenciosamente.
- Tokens no tema `mpgo` do `source.css`. Nada de hex solto em template.

---

*Dúvida sobre qualquer ponto: pergunte citando o número do item.*
