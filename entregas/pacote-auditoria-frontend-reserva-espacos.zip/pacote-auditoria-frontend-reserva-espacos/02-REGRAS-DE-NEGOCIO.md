# Anexo 02 — Regras de negócio

Separação explícita entre **regra de negócio** (não pode mudar durante o redesign) e **regra visual** (pode mudar livremente).

Fonte única da verdade: `codigo/reservations/validators.py`. Models, serializers DRF, camada de serviço e forms do admin **todos delegam para lá** — isso foi uma refatoração deliberada, documentada no docstring do módulo. Não reintroduzam validação duplicada em template ou view.

---

## 1. Estados da reserva

```
                    ┌──────────────┐
   criar ─────────▶ │  confirmed   │ ◀──── reagendar (volta para confirmed)
                    └──────┬───────┘
        check-in (janela)  │       │  15 min sem check-in
                    ┌──────▼────┐  │  (comando release_no_shows)
                    │ checked_in│  └──────────────▶ ┌──────────┐
                    └──────┬────┘                   │ no_show  │
                           │                        └──────────┘
              horário passa│
                    ┌──────▼────┐
                    │ completed │
                    └───────────┘

   confirmed ou checked_in ──── cancelar ────▶ ┌───────────┐
                                               │ cancelled │
                                               └───────────┘
```

| Status (valor no banco) | Rótulo | Ocupa a sala? |
|---|---|---|
| `confirmed` | Confirmada | ✅ **sim** |
| `checked_in` | Check-in realizado | ✅ **sim** |
| `cancelled` | Cancelada | ❌ não |
| `completed` | Concluída | ❌ não |
| `no_show` | Não compareceu | ❌ não |

`ACTIVE_RESERVATION_STATUSES = (confirmed, checked_in)` — **só esses dois bloqueiam um horário.** Constante em `reservations/enums.py`.

⚠️ Observação: a transição para `completed` **não tem código automático** no repositório. Existe o status e ele é usado nos filtros da tela "Minhas Reservas", mas nenhuma rotina o define. Na prática, uma reserva com check-in fica `checked_in` para sempre. Isso é uma lacuna conhecida (há uma spec em `codigo/docs/spec-driven/specs/06-spec-03-conclusao-automatica.md`), não um comportamento a replicar.

---

## 2. Regras de validação, com código e mensagem

Todas levantam `django.core.exceptions.ValidationError` com um `code` estável. Os serializers mapeiam `code` → campo do formulário, então **a mensagem pode ser reescrita, o code não**.

| Code | Mensagem atual | Campo na API | Quando dispara |
|---|---|---|---|
| `space_inactive` | "This space is not available for reservations." | `space` | criar reserva em espaço com `is_active=False` |
| `invalid_time_range` | "End time must be after start time." | `end_time` | `end_time <= start_time` |
| `reservation_overlap` | "This time slot overlaps with an existing reservation." | *(não-campo)* | choque com reserva `confirmed`/`checked_in` |
| `maintenance_overlap` | "This time slot overlaps with a maintenance block." | *(não-campo)* | choque com bloqueio de manutenção |
| `maintenance_reservation_overlap` | "This maintenance block overlaps with an existing reservation." | *(não-campo)* | admin tenta criar manutenção sobre reserva ativa |

⚠️ **As mensagens estão em inglês** e são exibidas cruas ao usuário final (`{{ error }}` no template). Isso é um bug de UX evidente numa interface em pt-BR — **corrigir faz parte legítima do redesign.** Traduzam as mensagens, mantenham os `code`.

Erros que **não** passam pelos validators e já estão em pt-BR:

| Origem | Mensagem |
|---|---|
| `ReservationCreateView` | "Formato de data ou hora inválido." |
| `ReservationCreateView` | "Selecione um espaço antes de reservar." |
| `services.check_in_reservation` | "Check-in is only available from 15 minutes before the start time until the end time." *(inglês)* |
| `services.cancel_reservation` | "Only confirmed or checked-in reservations can be cancelled." *(inglês)* |
| `OwnershipError` (via view) | "Você não tem permissão para cancelar esta reserva." |

---

## 3. Proteção contra sobreposição — 3 camadas

Isto é o coração do sistema. **Não simplificar.**

1. **Aplicação — `validators.validate_reservation_slot()`**
   `space.reservations.filter(status__in=ACTIVE, start_time__lt=end, end_time__gt=start)` — o teste clássico de interseção de intervalos, meio-aberto (`[start, end)`), então reservas adjacentes (10:00–11:00 e 11:00–12:00) **não** conflitam. Correto e intencional.

2. **Serviço — `services.create_reservation()`**
   Chama o validator, depois grava dentro de `transaction.atomic()`, e captura `IntegrityError`, reconvertendo para `ValidationError` com a mesma mensagem.

3. **Banco — `ExclusionConstraint` PostgreSQL**
   ```python
   ExclusionConstraint(
       name="exclude_overlapping_reservations",
       expressions=[(F("space"), RangeOperators.EQUAL),
                    (TstzRange(F("start_time"), F("end_time")), RangeOperators.OVERLAPS)],
       condition=Q(status__in=[CONFIRMED, CHECKED_IN]),
   )
   ```
   Exige a extensão `btree_gist` (migration `spaces/0002_enable_btree_gist.py`). **Vence qualquer corrida entre dois usuários clicando ao mesmo tempo.** Este é o motivo pelo qual PostgreSQL é obrigatório — o fallback SQLite do `settings.py` não suporta isso.

---

## 4. Check-in

`reservations/services.py::check_in_reservation()`

| Condição | Valor |
|---|---|
| Constante | `CHECK_IN_WINDOW_MINUTES = 15` |
| Status exigido | apenas `confirmed` |
| Janela válida | `start_time − 15min  ≤  agora  ≤  end_time` |
| Quem pode | **só o dono** (`OwnershipError` caso contrário) |
| Efeito | `status = checked_in`, `checked_in_at = agora` |

Fluxo real: QR Code colado na porta da sala → `/reservations/{id}/check-in/` → POST → status muda.

Na tela de detalhe, `can_check_in` é calculado na view e passado ao template — o botão só aparece dentro da janela.

---

## 5. No-show automático

`reservations/services.py::auto_release_no_shows(threshold_minutes=15)`

- Busca reservas `confirmed` com `start_time < agora − 15min` e marca como `no_show`.
- Executado por `python manage.py release_no_shows`.
- ⚠️ **Não há agendador no projeto.** Sem cron/systemd timer/Celery beat externo, isso **nunca roda**. É o pilar nº 2 do produto ("liberação automática de no-shows") e depende de configuração de infra.

Consequência para o redesign: se a interface prometer "libera automaticamente em 15 min", confirmem antes que o cron está configurado no ambiente de destino.

---

## 6. Bloqueios de manutenção

`MaintenanceBlock`: `space`, `start_time`, `end_time`, `reason` (texto), `created_by`.

- Impedem qualquer reserva no intervalo.
- **Não podem ser criados sobre uma reserva ativa** — o admin recebe erro e precisa cancelar a reserva primeiro. (Decisão de produto: manutenção não atropela reserva de usuário.)
- Só admin cria/remove.
- **Classificação por IA:** ao digitar o motivo em texto livre, o admin pode pedir uma sugestão de categoria (`POST /admin-dashboard/maintenance/classify/` → Groq). Categorias fixas: `eletrica`, `hidraulica`, `limpeza`, `ti_equipamentos`, `mobiliario`, `seguranca`, `outros`. A sugestão vem com justificativa e nível de confiança, e é apenas **sugestão** — não é gravada automaticamente. Template: `_maintenance_ai_suggestion.html`.

---

## 7. Propriedade e permissão sobre a reserva

| Ação | Dono | Admin |
|---|---|---|
| Ver detalhe | ✅ (`get_object_or_404(..., user=request.user)`) | via lista admin |
| Cancelar | ✅ se `confirmed`/`checked_in` | ✅ qualquer uma (`admin_cancel_reservation`) |
| Reagendar | ✅ se `confirmed`/`checked_in` | ❌ **não existe reagendamento pelo admin** |
| Check-in | ✅ | ❌ não pode fazer check-in por outro |

**Detalhe de segurança:** `ReservationDetailView` filtra por `user=request.user` na própria query — um admin **não consegue** abrir `/reservations/{id}/` de outro usuário. Ele só vê os dados pela lista de `/admin-dashboard/reservations/`.

---

## 8. Reagendamento

`services.reschedule_reservation()`

- Só o dono.
- Revalida **todas** as regras de conflito, excluindo a própria reserva do teste (`exclude_pk`).
- **Exceção deliberada:** `require_active_space=False`. Se o espaço foi desativado depois, a reserva existente continua reagendável. Está comentado no código como decisão consciente — não "consertem" isso.
- Sempre volta o status para `confirmed` (mesmo se estava `checked_in`).

---

## 9. O que NÃO existe (confirmação explícita)

Nenhuma destas regras está implementada. Se o redesign sugerir qualquer uma na interface, estará prometendo algo que o sistema não faz:

- ❌ antecedência mínima ou máxima
- ❌ **validação de data no passado** — dá para reservar ontem
- ❌ duração máxima da reserva
- ❌ limite de reservas simultâneas por usuário
- ❌ reserva recorrente
- ❌ fluxo de aprovação (de qualquer tipo)
- ❌ horário de funcionamento / expediente
- ❌ bloqueio de fim de semana
- ❌ calendário de feriados
- ❌ número de participantes (campo inexistente)
- ❌ validação contra a capacidade do espaço
- ❌ reserva de equipamento individual
- ❌ notificação por e-mail ou push (nenhum `EMAIL_BACKEND` configurado)
- ❌ lista de espera
- ❌ relatórios / exportação

---

## 10. Regras **visuais** — livres para mudar

- Cores, tipografia, espaçamento, raios, sombras (respeitando "vermelho só em CTA/ativo/crítico" e o tema `mpgo`).
- Layout dos cards, do grid e dos filtros.
- Textos de rótulo, placeholder, vazio e erro (**por favor, traduzam para pt-BR**).
- Grade de horários: hoje é uma lista de botões de intervalos mesclados; pode virar timeline, calendário ou o que fizer sentido — desde que continue consumindo `{occupied[], free[]}`.
- Stepper: hoje é texto simples "1. Espaço / 2. Horário / 3. Confirmação".
- Estados de loading: hoje é `.htmx-indicator` com spinner DaisyUI. Skeletons são bem-vindos — só precisam continuar sendo acionados pela classe `htmx-request`, não por JS próprio.
- Tabs de "Minhas Reservas" (Ativas / Passadas / Canceladas) — os contadores vêm da view, o visual é livre.

---

## 11. Fusos e formatação — cuidado

- `TIME_ZONE = "UTC"`, `USE_TZ = True`.
- O formulário de reserva faz `datetime.strptime(...).replace(tzinfo=datetime.UTC)` — trata o que o usuário digitou **como se fosse UTC**, sem converter de Goiás (UTC−3).
- Os templates exibem horário fatiando a string ISO (`{{ slot.start|slice:"11:16" }}`), o que também mostra UTC cru.

Resultado: um usuário que reserva "14:00" grava 14:00 UTC = 11:00 em Goiás. **Isso é um bug de backend, não de UI**, mas o redesign vai torná-lo mais visível. Recomendação: corrigir junto (`TIME_ZONE = "America/Sao_Paulo"` + `localtime` nos templates + parsing com `django.utils.timezone.make_aware`), como item separado e testado.
