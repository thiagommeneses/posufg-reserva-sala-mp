# Anexo 03 — Mapa de telas e componentes

Descrição estrutural de **todas** as telas existentes (item 21 do pedido). Cada tela indica: rota, view, template, blocos visuais, estados e o arquivo de screenshot correspondente em `screenshots/`.

Legenda de estado: **[vazio]** = empty state · **[erro]** = estado de erro · **[loading]** = indicador de carregamento.

---

## Inventário — 16 telas

| # | Tela | Rota | Perfil | Screenshot |
|---|---|---|---|---|
| 01 | Login | `/accounts/login/` | público | `01-login.png` |
| 02 | Registro | `/accounts/register/` | público | `02-registro.png` |
| 03 | Buscar espaços | `/spaces/` | usuário | `03-espacos-busca.png` |
| 04 | Detalhe do espaço + disponibilidade | `/spaces/{id}/` | usuário | `04-espaco-detalhe.png` |
| 05 | Nova reserva | `/reservations/new/?space={id}` | usuário | `05-nova-reserva.png` |
| 06 | Minhas reservas | `/reservations/` | usuário | `06-minhas-reservas.png` |
| 07 | Detalhe da reserva | `/reservations/{id}/` | usuário | `07-reserva-detalhe.png` |
| 08 | Reagendar reserva | `/reservations/{id}/reschedule/` | usuário | `08-reserva-reagendar.png` |
| 09 | Consultar normas (IA) | `/assistente/` | usuário | `09-assistente-normas.png` |
| 10 | Dashboard admin | `/admin-dashboard/` | admin | `10-admin-dashboard.png` |
| 11 | Espaços (lista) | `/admin-dashboard/spaces/` | admin | `11-admin-espacos-lista.png` |
| 12 | Espaço (form) | `/admin-dashboard/spaces/new/` | admin | `12-admin-espaco-form.png` |
| 13 | Reservas (admin) | `/admin-dashboard/reservations/` | admin | `13-admin-reservas.png` |
| 14 | Manutenção (lista) | `/admin-dashboard/maintenance/` | admin | `14-admin-manutencao-lista.png` |
| 15 | Manutenção (form + IA) | `/admin-dashboard/maintenance/new/` | admin | `15-admin-manutencao-form.png` |
| 16 | Usuários | `/admin-dashboard/users/` | admin | `16-admin-usuarios.png` |

**Não existe:** tela de calendário, tela de relatórios, tela de configurações, tela de ajuda, tela de perfil do usuário, tela de aprovação de reserva.

---

## Dois layouts-base

### `base.html`
`<html lang="pt-BR" data-theme="mpgo">` · `{% tailwind_css %}` · htmx 2.0.4 via CDN · `{% include "partials/_messages.html" %}` no topo do body (toasts do framework de mensagens do Django) · bloco `content`.

### `base_user.html` — layout do usuário
```
drawer lg:drawer-open
├── drawer-content  (bg-base-200)
│   ├── header navbar  ← só em < lg (h-14, sticky, logo + "Reservas" + botão hambúrguer)
│   └── main  (p-4 sm:p-6 lg:p-8, max-w-6xl, mx-auto)
│         └── block user_content
└── drawer-side (w-60, bg-base-100, border-r)
    ├── marca: logo h-9 + "Reserva de Espaços" + "Olá, {username}"
    ├── ATALHOS: Espaços · Minhas Reservas · Consultar Normas
    ├── ADMINISTRAÇÃO (só is_staff): Painel Admin
    └── rodapé: Sair (form POST)
```

### `base_admin.html` — layout do admin
Igual, com `w-64`, marca "Admin", 5 itens de menu (Dashboard, Espaços, Reservas, Manutenção, Usuários), rodapé "Voltar ao Site", `main` com `max-w-7xl`.

---

## 01 — Login `/accounts/login/`

`accounts/views.py::login_view` → `templates/accounts/login.html` (estende `base.html`, **sem sidebar**)

```
tela cheia, bg-base-200, centralizada
└── coluna max-w-sm
    ├── logo h-16 sm:h-20 + "Reserva de Espaços" (brand-font, 2xl/3xl)
    └── .surface p-6 sm:p-8
        ├── h1 "Entrar" + subtítulo
        ├── campo Usuário  (input-error + <p> de erro se inválido)
        ├── campo Senha    (idem)
        ├── btn-primary largura total "Entrar" + ícone login
        └── "Não tem conta? Criar conta"
```

**[erro]** mensagem "Usuário ou senha inválidos." vem pelo `messages` framework (toast no topo) **e** os campos ganham `input-error`.
Redireciona: staff → `/admin-dashboard/`, comum → `/spaces/`.

⚠️ O README menciona uma escolha "Admin / Usuário" no login — **isso não existe mais no template atual**. Documentação desatualizada.

---

## 02 — Registro `/accounts/register/`

Mesma estrutura do login. Campos: usuário, e-mail, senha, confirmar senha. Cria sempre usuário comum e já faz login.

---

## 03 — Buscar espaços `/spaces/` ⭐ *é a tela do screenshot original*

`spaces/views.py::SpaceListView` → `space_list.html` + `_space_list_results.html`

```
space-y-6
├── header: h1 "Buscar espaços" (2xl semibold)
│           p  "Encontre salas por linguagem natural ou filtros."
│
├── .surface p-5 sm:p-6   ── BUSCA COM IA (form hx-get → #space-results)
│   ├── h2 "Busca com IA" (sm semibold)
│   ├── p  exemplos de uso
│   └── flex: input text "Descreva o que você precisa…"  +  btn-outline "Buscar com IA"
│                                                            + ícone send + [loading] spinner
│
├── .surface p-5 sm:p-6   ── FILTROS (form hx-get → #space-results)
│   ├── h2 "Filtros"
│   ├── grid 1 / sm:2 / lg:4
│   │   ├── Capacidade mínima (number)
│   │   ├── Capacidade máxima (number)
│   │   ├── Localização (text)
│   │   └── btn-primary "Filtrar" + ícone filter + [loading]
│   └── divisória + "Equipamentos": 7 checkboxes inline
│        └── cada checkbox dispara hx-get sozinho (hx-include="closest form")
│
└── #space-results   ── ALVO HTMX
    ├── [erro]  .notice-error com ai_error   (+ console.warn do detalhe técnico)
    ├── ou      .notice "Entendi: {ai_summary}"
    ├── grid 1 / md:2 / lg:3, gap-4
    │   └── <article class="surface p-5">  ── CARD DO ESPAÇO
    │       ├── h2 nome (base semibold)
    │       ├── badges: "{capacity} lugares" (outline) + "{location}" (ghost)
    │       ├── descrição (line-clamp-2) — na prática sempre ausente
    │       ├── badges de atributos (outline, um por equipamento)
    │       └── mt-auto: btn-primary btn-sm "Ver disponibilidade" + ícone calendar
    └── [vazio] .notice "Nenhum espaço encontrado com os filtros selecionados."
```

**Card hoje:** sem foto, sem estado de disponibilidade, sem preço/tipo. Hover = `hover:border-base-content/20` (só a borda escurece — não desloca layout).

---

## 04 — Detalhe do espaço `/spaces/{id}/`

`SpaceDetailView` → `space_detail.html` + `_availability.html`

```
max-w-4xl space-y-6
├── stepper "1. Espaço / 2. Horário / 3. Confirmação"  (passo 2 ativo)
├── .surface  ── IDENTIFICAÇÃO
│   ├── h1 nome
│   ├── badges capacidade + localização
│   ├── descrição
│   └── badges de atributos
└── .surface  ── DISPONIBILIDADE
    ├── h2 "Disponibilidade"
    ├── <input type="date">  hx-get no change → #availability-content  + [loading]
    └── #availability-content  ← _availability.html
        ├── legenda: ● verde Disponível · ▪ cinza Reservado · ▪ âmbar Manutenção
        ├── grid 1 / sm:2 / md:3 / lg:4 de botões
        │   ├── LIVRE      → <a> outline verde, clicável → /reservations/new/?space=&start=
        │   ├── RESERVADO  → <button disabled> cinza (bg-base-200)
        │   └── MANUTENÇÃO → <button disabled> âmbar (bg-warning/10)
        └── [vazio] .notice "Não há horários disponíveis para esta data."
```

⚠️ Os horários exibidos são o **ISO fatiado** (`|slice:"11:16"`) — ou seja, **UTC cru**. Ver anexo 02, seção 11.

---

## 05 — Nova reserva `/reservations/new/?space={id}&start={ISO}`

`ReservationCreateView` → `reservation_form.html`

```
max-w-xl space-y-6
├── stepper (passo 3)
├── header "Nova reserva" / "Confirme o horário desejado."
├── .surface  ── RESUMO DO ESPAÇO (só se ?space= presente)
│   └── nome + badges capacidade/localização + descrição
└── .surface  ── FORMULÁRIO
    ├── [erro] .notice-error com a mensagem do validator (⚠️ hoje em inglês)
    ├── Data       <input type="date">   required
    ├── grid 2 col: Início / Término  <input type="time">  required
    └── btn-primary largura total "Reservar" + ícone calendar
└── link ghost "← Voltar aos espaços"
```

**Este é o "ReservationSummary" que vocês desenharam** — hoje é só o bloco de resumo do espaço. Não há resumo de custo, participantes ou finalidade porque esses campos não existem.

---

## 06 — Minhas reservas `/reservations/`

`ReservationListView` → `reservation_list.html`

```
max-w-3xl space-y-6
├── header "Minhas reservas" / "Acompanhe e gerencie suas reservas."
├── TABS (links ?tab=, borda inferior, ativa = border-primary text-primary)
│   Ativas (n) · Passadas (n) · Canceladas (n)
├── lista space-y-3
│   └── <article class="surface p-4 sm:p-5" id="reservation-{id}">
│       ├── esquerda: nome do espaço (semibold, truncate)
│       │             "24/08/2026 14:00 — 15:00"
│       │             localização (xs, /45)
│       ├── direita: badge de status
│       └── rodapé direita: btn-outline btn-sm "Ver detalhes" + ícone eye
├── [vazio-categoria] .notice "Nenhuma reserva encontrada nesta categoria."
└── [vazio-total]     .notice "Você ainda não tem reservas. [Buscar espaços]"
```

Tabs são **links normais** (recarregam a página), não HTMX.

### Badge de status — `components/_reservation_status_badge.html`

| Status | Rótulo | Estilo |
|---|---|---|
| `confirmed` | Confirmada | outline, borda `success/40`, texto success |
| `checked_in` | Check-in | outline neutro |
| `completed` | Concluída | ghost, texto `/50` |
| `no_show` | No-show | outline, borda `error/40`, texto error |
| `cancelled` | Cancelada | ghost, texto `/50` |

---

## 07 — Detalhe da reserva `/reservations/{id}/`

`ReservationDetailView` → `reservation_detail.html`

```
max-w-xl space-y-6
├── header: h1 "Detalhes da reserva" + nome do espaço   |   badge de status
└── .surface #reservation-actions        ← ALVO HTMX (hx-swap="outerHTML")
    ├── <dl> grid 1 / sm:2 — Espaço · Localização · Capacidade · Status
    │                        Início · Término · (Check-in, se houver)
    └── rodapé com divisória:
        ├── esquerda: btn-ghost "← Voltar"
        └── direita (condicional):
            ├── "Fazer check-in"  (verde outline) — se can_check_in
            ├── "Reagendar"       (outline)       — se can_reschedule
            └── "Cancelar"        (vermelho outline) — se can_cancel
```

Cancelar e check-in usam `hx-confirm` (o **`confirm()` nativo do browser**) e trocam o bloco inteiro. Um redesign que queira um modal bonito precisa substituir o `hx-confirm` por um `<dialog>` DaisyUI — e aí é a **primeira modal do sistema**.

---

## 08 — Reagendar `/reservations/{id}/reschedule/`

Mesma estrutura de 05, pré-preenchida com o horário atual da reserva.

---

## 09 — Consultar normas `/assistente/`

`knowledge/views.py::DocumentAssistantView` → `assistant.html` + `_assistant_answer.html`
**É a tela mais elaborada do sistema e não aparecia em nenhum mockup.**

```
grid lg:[1fr | 20rem]  xl:[1fr | 22rem]
├── COLUNA PRINCIPAL
│   ├── header "Consultar normas" + "· N docs · M instituições"
│   ├── .surface — form hx-post → #answer
│   │   ├── input "Ex.: com quanta antecedência preciso reservar o auditório?"
│   │   ├── btn-primary "Perguntar" + [loading]
│   │   └── chips de perguntas sugeridas (btn-ghost btn-xs com borda)
│   └── #answer  ← resposta + fontes citadas
└── ASIDE (sticky, max-h calc(100vh - 5.5rem))
    ├── "Histórico" + contador + "As 3 últimas entram no contexto."
    ├── lista rolável de turnos: pergunta (line-clamp-2) + trecho da resposta
    │   + data/hora + "N fontes"; clicar reutiliza a pergunta
    └── [vazio] "Nenhuma consulta ainda"
```

⚠️ Único lugar do sistema com `onclick` inline em JS. Se refatorarem, preservem o comportamento.

---

## 10 — Dashboard admin `/admin-dashboard/`

```
space-y-8
├── header "Dashboard" / "Visão geral da ocupação e indicadores do dia."
├── grid 1 / sm:2 / lg:4 — 4 KPIs em .surface
│   ├── Espaços totais       (neutro)
│   ├── Ocupados agora       (text-error)
│   ├── Disponíveis agora    (text-success)
│   └── No-shows hoje        (text-warning)
└── section "Ocupação em tempo real" / "Atualiza automaticamente a cada 30 segundos."
    └── #occupancy-grid   hx-trigger="every 30s"  ← _occupancy_grid.html
        └── cards de espaço com status Livre (verde) / Ocupado (vermelho) / Manutenção (âmbar)
```

Números usam `tabular-nums`. O polling de 30s é um comportamento existente — mantenham.

---

## 11 — Espaços, lista `/admin-dashboard/spaces/`

```
header: h1 "Espaços" + subtítulo   |   btn-primary "＋ Novo espaço"
.surface > overflow-x-auto > <table class="table">
  colunas: Nome | Capacidade | Localização | Atributos (badges) | Status | (ação)
  linha:   hover:bg-base-200/50, borda inferior
  Status:  _space_status_badge.html — clicável, faz PATCH via HTMX e troca só o badge
  ação:    btn-ghost btn-xs "✎ Editar"
[vazio] linha única colspan=6: "Nenhum espaço encontrado."
```

---

## 12 — Espaço, formulário `/admin-dashboard/spaces/new/` e `/{pk}/`

```
mx-auto max-w-xl
├── "← Voltar" + h1 "Novo espaço" | "Editar espaço"
└── .surface > form
    ├── [erro] .notice-error com non_field_errors
    ├── loop genérico {% for field in form %}
    │   ├── label + widget + <p class="text-xs text-error"> por campo
    │   └── EXCEÇÃO: campo "attributes" vira chips (label com borda, checkbox + texto)
    └── btn-primary "Salvar" + btn-ghost "Cancelar"
```

Campos: Nome · Descrição · Capacidade · Localização · Ativo · Atributos.

---

## 13 — Reservas, admin `/admin-dashboard/reservations/`

```
header "Reservas"
.surface — form de filtro (hx-get, hx-push-url="true" → #reservation-table-container)
  grid 1 / md:2 / xl:5 — Status(select) · Espaço(select) · De(date) · Até(date) · Usuário(text)
  botões: "Filtrar" + "Limpar" + [loading]
#reservation-table-container ← _reservation_table.html
  tabela paginada (25/página); cada linha _reservation_row.html com ação de cancelar via HTMX
```

Único lugar do sistema com **paginação** e com `hx-push-url` (mantém o filtro na URL).

---

## 14 e 15 — Manutenção

**Lista** `/admin-dashboard/maintenance/`: tabela Espaço · Início · Fim · Motivo · ação excluir (DELETE via HTMX, remove a linha).

**Formulário** `/admin-dashboard/maintenance/new/`: Espaço (select) · Início e Fim (`datetime-local`) · Motivo (textarea) — **mais o bloco de sugestão da IA**: um botão dispara `hx-post` para `/maintenance/classify/` e devolve `_maintenance_ai_suggestion.html` com categoria sugerida, justificativa e confiança. Estado de erro próprio (`ai_error`).

---

## 16 — Usuários `/admin-dashboard/users/`

Tabela Usuário · E-mail · Staff · Ativo · ações (editar / excluir via HTMX).
Formulário: usuário · e-mail · is_staff · is_active · senha + confirmação (opcional na edição).
Regra: admin não remove a própria conta — devolve `<span class="text-error">` com a mensagem.

---

## Componentes reutilizáveis existentes

| Arquivo | Papel |
|---|---|
| `partials/_icon.html` | 15 ícones SVG inline: `arrow-left`, `calendar`, `check`, `clear`, `eye`, `filter`, `login`, `pencil`, `plus`, `refresh`, `save`, `sparkles`, `trash`, `user-plus`, `x`. Uso: `{% include "partials/_icon.html" with name="filter" %}` |
| `partials/_messages.html` | toasts do framework de mensagens do Django |
| `partials/_send_badge.html` | badge "enviar" dos botões de IA (aceita `inverted=True`) |
| `components/_reservation_steps.html` | stepper de 3 passos |
| `components/_reservation_status_badge.html` | badge de status da reserva |
| `admin_dashboard/_space_status_badge.html` | badge Ativo/Inativo clicável |
| `admin_dashboard/_occupancy_grid.html` | grade de ocupação em tempo real |
| `admin_dashboard/_reservation_table.html` / `_reservation_row.html` | tabela e linha de reserva |
| `admin_dashboard/_user_row.html` / `_maintenance_row.html` | linhas de tabela |
| `admin_dashboard/_maintenance_ai_suggestion.html` | resultado da classificação por IA |
| `spaces/_space_list_results.html` | grid de cards de espaço |
| `spaces/_availability.html` | grade de horários |
| `knowledge/_assistant_answer.html` | resposta do assistente com fontes |

**Não existe:** wrapper de Button, Input, Card, Modal, Tooltip, Skeleton ou Toast próprio. Tudo isso é classe DaisyUI aplicada direto no HTML.

---

## Alvos HTMX — quebrar qualquer um destes quebra a aplicação em silêncio

| `id` | Página | O que faz |
|---|---|---|
| `#space-results` | `/spaces/` | recebe o grid de cards filtrado |
| `#ai-loading-indicator` | `/spaces/` | spinner da busca com IA |
| `#loading-indicator` | `/spaces/` | spinner dos filtros |
| `#availability-content` | `/spaces/{id}/` | recebe a grade de horários |
| `#availability-loading` | `/spaces/{id}/` | spinner da disponibilidade |
| `#reservation-actions` | `/reservations/{id}/` | bloco trocado após cancelar/check-in |
| `#occupancy-grid` | `/admin-dashboard/` | polling de 30s |
| `#reservation-table-container` | admin reservas | tabela filtrada |
| `#filter-indicator` | admin reservas | spinner do filtro |
| `#answer` | `/assistente/` | resposta do assistente |
| `#qa-loading` | `/assistente/` | spinner do assistente |

Regra prática para o redesign: **renomear um `id` é uma mudança de comportamento, não de estilo.**

---

## Custo por campo novo que vocês querem adicionar

| Campo proposto | Custo |
|---|---|
| Imagem de capa | migration + Pillow + storage + form + 3 templates de card + serializer — ver anexo 05 |
| Galeria de fotos | tudo acima + tabela nova + ordenação + UI de reordenar |
| Tipo do espaço | migration (`CharField` com `choices` ou FK) + filtro + form + navegação por categoria na sidebar |
| Descrição curta | migration (simples) + form + card |
| Características (≠ equipamentos) | precisa definir o que é. Se for outra lista, é outra tabela `Attribute`-like |
| Requer aprovação | migration + **novo status** `pending` + fluxo de aprovação + tela admin + notificação. **É feature, não redesign** |
| Nome completo / departamento do usuário | modelo `Profile` novo (OneToOne) + migration + form de registro + sidebar |
| Estado de disponibilidade no card | query agregada nova (senão é N+1) — ver auditoria, item 13 |
