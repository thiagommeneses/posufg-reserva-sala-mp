# Anexo 05 — Fotos dos espaços: proposta técnica completa

Responde aos itens 8 e 9 do pedido. **Este é o único ponto do redesign que obrigatoriamente mexe em banco, backend e infraestrutura.**

---

## Ponto de partida

| Pergunta | Resposta |
|---|---|
| Existe campo de imagem em `Space`? | **Não.** O modelo tem 7 campos, nenhum de mídia |
| Existe upload de arquivo no sistema? | **Não.** Nenhum |
| Existe `MEDIA_ROOT` / `MEDIA_URL`? | **Não** estão no `settings.py` |
| Existe Pillow instalado? | **Não** está no `pyproject.toml` |
| Existe storage configurado (S3, MinIO, etc.)? | **Não** |
| Existe `django-storages`? | **Não** |

Ou seja: parte-se do zero. A boa notícia é que **nenhuma regra de negócio é tocada** — foto é metadado do espaço, não afeta reserva, conflito, check-in ou no-show.

---

## Decisão 1 — Capa apenas, ou capa + galeria?

**Recomendação: fazer em duas fases.**

### Fase 1 — só a capa (resolve o mockup)

```python
# spaces/models.py
class Space(models.Model):
    ...
    cover_image = models.ImageField(
        upload_to="spaces/covers/%Y/%m/",
        blank=True,
        null=True,
        verbose_name="Imagem de capa",
    )
```

Uma migration, um campo no form, um `<img>` no card. É o mínimo que entrega o visual desenhado.

### Fase 2 — galeria (se e quando fizer sentido)

```python
class SpaceImage(models.Model):
    space      = models.ForeignKey(Space, on_delete=models.CASCADE, related_name="images")
    image      = models.ImageField(upload_to="spaces/gallery/%Y/%m/")
    caption    = models.CharField(max_length=200, blank=True)   # vira o alt
    is_cover   = models.BooleanField(default=False)
    sort_order = models.PositiveSmallIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["sort_order", "id"]
        constraints = [
            models.UniqueConstraint(
                fields=["space"],
                condition=models.Q(is_cover=True),
                name="unique_cover_per_space",
            ),
        ]
```

A `UniqueConstraint` parcial garante **no máximo uma capa por espaço** no nível do banco — o mesmo padrão de rigor já usado na `ExclusionConstraint` das reservas.

⚠️ Se a Fase 2 for feita, `Space.cover_image` da Fase 1 deve ser migrado para `SpaceImage(is_cover=True)` e depois removido. **Decidam antes de começar** se vão direto para a Fase 2, para não pagar a migração duas vezes.

---

## Decisão 2 — Storage

Contexto real: ambiente institucional MPGO, deploy por **Docker Compose** (`web` + `db`), sem cloud declarada, sem CDN.

| Opção | Veredito |
|---|---|
| **Filesystem + volume Docker** | ✅ **Recomendado.** É o `FileSystemStorage` padrão do Django. Zero dependência nova, zero custo, zero conta em nuvem. Basta declarar um volume nomeado no `docker-compose.yml` para `MEDIA_ROOT` |
| MinIO (S3 self-hosted) | ⚠️ Só se já houver instância institucional. Senão é mais um contêiner para operar por causa de ~50 JPEGs |
| S3 / Azure Blob / GCS | ❌ Provavelmente inviável em órgão público sem contrato de nuvem já vigente. Além disso exige `django-storages` + credenciais em produção |
| Blob no PostgreSQL | ❌ Não. Infla dumps, complica backup, sem ganho |
| Supabase Storage | ❌ Sem relação com a stack |

**Escala real do problema:** 5 espaços no seed; realisticamente algumas dezenas. Uma capa de ~200 KB × 50 espaços = 10 MB. Não justifica infraestrutura de objeto.

### Configuração mínima

```python
# config/settings.py
MEDIA_URL = "media/"
MEDIA_ROOT = BASE_DIR / "media"
```

```python
# config/urls.py — SÓ em desenvolvimento
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
```

```yaml
# docker-compose.yml
services:
  web:
    volumes:
      - media_data:/app/media
volumes:
  media_data:
```

⚠️ **Em produção o Django não deve servir mídia.** Ou entra um nginx/WhiteNoise na frente, ou a rota fica atrás do servidor de aplicação. Definir isso é parte da entrega — não deixar `DEBUG=True` só para as fotos aparecerem.

Também: incluir `media/` no `.gitignore` e no `.dockerignore`, e o volume na rotina de backup (hoje o backup provavelmente só cobre o Postgres — **uma foto perdida não é recuperável pelo dump do banco**).

---

## Decisão 3 — Validação e processamento

```python
# spaces/validators.py  (arquivo novo)
MAX_IMAGE_BYTES = 5 * 1024 * 1024          # 5 MB
ALLOWED_CONTENT_TYPES = {"image/jpeg", "image/png", "image/webp"}
MIN_DIMENSIONS = (800, 450)                 # garante nitidez no card 16:9
```

| Item | Definição |
|---|---|
| Extensões aceitas | `.jpg`, `.jpeg`, `.png`, `.webp` |
| MIME | validar o **conteúdo real** (Pillow abre e identifica), não confiar na extensão nem no header do cliente |
| Tamanho máximo | 5 MB no upload |
| Dimensão mínima | 800×450 px |
| Proporção | aceitar qualquer uma; o recorte é visual (`object-fit: cover`) |
| Processamento no servidor | redimensionar para no máximo **1600px de largura**, converter para WebP com qualidade 82, gerar thumbnail de **400px** para o card |
| Nome do arquivo | UUID — **nunca** o nome enviado pelo usuário (evita path traversal e colisão) |
| EXIF | remover metadados (podem conter geolocalização) e aplicar a rotação antes de descartar |
| Quem pode enviar | somente `is_staff` (mesma barreira de `SpaceForm`) |
| Remoção | soft: limpar o campo; o arquivo antigo deve ser apagado do disco por sinal `post_delete`/`pre_save`, senão o volume cresce indefinidamente |

Dependência nova: **Pillow** (obrigatória para `ImageField`, e é o que faz o resize). Uma linha no `pyproject.toml`.

Regra de segurança que vale explicitar: `ImageField` valida que é imagem, mas **não impede SVG malicioso** se `.svg` for permitido. Por isso a lista acima **não inclui SVG**.

---

## Decisão 4 — Fallback

Concordamos integralmente: card quebrado é pior que card sem foto.

```
Espaço tem cover_image?
├── SIM → <img src="{{ space.cover_image.url }}"
│              alt="Foto do espaço {{ space.name }}"
│              loading="lazy" decoding="async"
│              class="w-full h-full object-cover">
└── NÃO → placeholder institucional
          fundo base-200 + ícone de sala centralizado (base-content/20)
          SEM texto "sem imagem"  ← ruído visual
```

**Não usar o logo do MPGO como placeholder** — o logo é marca, não ilustração; repeti-lo em 20 cards banaliza a identidade. Um ícone geométrico neutro sobre `base-200` é o certo.

Além disso, tratar o erro de carregamento: se a URL existe mas o arquivo sumiu do volume, a imagem quebra. Como não queremos JS, a saída é garantir a integridade no servidor (sinal de `post_delete`) e, no template, só renderizar `<img>` se `space.cover_image` for truthy.

---

## Especificação visual do card com foto

```
┌────────────────────────────┐
│                            │  ← área de imagem
│          FOTO              │     aspect-ratio: 16 / 9   (não 16/6)
│                            │     object-fit: cover
├────────────────────────────┤     border-radius: só cantos superiores
│ Sala de Reunião Alfa       │     (var(--radius-box) = 0.5rem)
│ [8 lugares] [2º andar,A]   │
│ [TV] [Wi-Fi] [Videoconf.]  │
│ ● Disponível               │  ← ver ressalva abaixo
│ [ Ver disponibilidade ]    │
└────────────────────────────┘
```

| Propriedade | Valor |
|---|---|
| Proporção | **16:9** — é a proporção que qualquer celular produz; 16:6 obrigaria recorte agressivo em toda foto |
| `object-fit` | `cover` |
| `object-position` | `center` |
| Raio | `rounded-t-[--radius-box]` (só topo; o card já tem 0.5rem) |
| `loading` | `lazy` em todos, **exceto** os 3 primeiros do grid |
| `decoding` | `async` |
| `alt` | `"Foto do espaço {nome}"` — nunca vazio, nunca "imagem" |
| [loading] | skeleton com **a mesma proporção 16:9** (`skeleton` do DaisyUI), para não haver salto de layout |
| Hover | `border-color` apenas. **Não** aplicar `scale` na imagem: desloca layout e é custoso em lista longa |
| Selecionado | borda `primary` + `ring-2 ring-primary/20` + check no canto superior direito + `aria-selected="true"`. **Não existe hoje** — o card atual não é selecionável, é um link |

⚠️ **`● Disponível` no card não tem dado por trás hoje.** Ver auditoria, item 13, antes de desenhá-lo como se existisse.

---

## Impacto arquivo a arquivo (Fase 1)

| Arquivo | Mudança |
|---|---|
| `pyproject.toml` | + `pillow` |
| `config/settings.py` | + `MEDIA_URL`, `MEDIA_ROOT` |
| `config/urls.py` | + rota de mídia em DEBUG |
| `docker-compose.yml` | + volume `media_data` |
| `.gitignore` / `.dockerignore` | + `media/` |
| `spaces/models.py` | + `cover_image` |
| `spaces/migrations/0003_space_cover_image.py` | **nova** |
| `spaces/validators.py` | **novo** (tamanho, MIME, dimensão) |
| `spaces/signals.py` | **novo** (apagar arquivo órfão) |
| `spaces/serializers.py` | + `cover_image_url` no `fields` |
| `admin_dashboard/forms.py` | + `cover_image` em `SpaceForm.Meta.fields` + widget de arquivo |
| `admin_dashboard/views.py` | ⚠️ **`CreateView`/`UpdateView` precisam receber `request.FILES`** — hoje o form é instanciado sem isso |
| `templates/admin_dashboard/space_form.html` | + `enctype="multipart/form-data"` no `<form>` ⚠️ **esquecer isso é o erro nº 1**; + preview da imagem atual + botão remover |
| `templates/admin_dashboard/space_list.html` | + miniatura na tabela (opcional) |
| `templates/spaces/_space_list_results.html` | + bloco de imagem no card |
| `templates/spaces/space_detail.html` | + imagem grande no topo |
| `templates/reservations/reservation_form.html` | + miniatura no resumo do espaço |
| `spaces/tests.py` | + testes de upload, validação e fallback |
| `core/seeds/spaces.py` | (opcional) fotos de exemplo para demo |

**Nenhuma alteração em:** `reservations/*`, `ai_assistant/*`, `knowledge/*`, `accounts/*`. As regras de negócio ficam intocadas.

---

## Admin: fluxo de gestão da foto

```
/admin-dashboard/spaces/{id}/   (Editar espaço)
├── Nome · Descrição · Capacidade · Localização · Ativo · Atributos   ← já existe
└── NOVO: Imagem de capa
    ├── preview atual (16:9, mesma proporção do card)
    ├── [Selecionar arquivo]   → mostra nome + tamanho antes de enviar
    ├── [Remover imagem]       → checkbox "limpar" (padrão do ClearableFileInput)
    └── ajuda: "JPG, PNG ou WebP. Mínimo 800×450 px. Máximo 5 MB.
                A imagem é recortada no formato 16:9 no card."
```

Para a Fase 2 (galeria), acrescentar: lista das fotos com miniatura, marcar capa (radio), reordenar e excluir. **Reordenar por drag-and-drop exige JavaScript** — se quiserem manter zero-JS, use botões ↑/↓ com HTMX, que é consistente com o resto do sistema.

---

## Contrato de API atualizado

```json
{
  "id": 1,
  "name": "Sala de Reunião Alfa",
  "description": null,
  "capacity": 8,
  "location": "2º andar, Bloco A",
  "is_active": true,
  "cover_image_url": "/media/spaces/covers/2026/08/3f2b9c1e-....webp",
  "cover_image_thumb_url": "/media/spaces/covers/2026/08/3f2b9c1e-...-400.webp",
  "created_at": "2026-08-24T13:02:11.482913Z",
  "updated_at": "2026-08-24T13:02:11.482913Z",
  "attributes": ["Ar-condicionado", "TV", "Videoconferência", "Wi-Fi"]
}
```

`null` quando não há foto — o cliente decide o fallback. Usar **URL absoluta** (`request.build_absolute_uri`) se a API for consumida fora do mesmo host.

---

## Checklist de aceite

- [ ] Espaço sem foto renderiza o placeholder, não um card quebrado
- [ ] Card com foto tem exatamente a mesma altura do card sem foto
- [ ] Nenhum salto de layout (CLS) durante o carregamento — skeleton na proporção certa
- [ ] `alt` descritivo em todas as imagens
- [ ] Upload de arquivo não-imagem renomeado para `.jpg` é rejeitado
- [ ] Upload acima de 5 MB é rejeitado com mensagem clara em pt-BR
- [ ] Trocar a foto apaga o arquivo antigo do disco
- [ ] Excluir o espaço apaga os arquivos
- [ ] Usuário não-staff não consegue fazer upload por nenhuma via (incluindo POST direto na API)
- [ ] Foto sobrevive a `docker compose down && up` (volume nomeado, não bind mount temporário)
- [ ] Volume de mídia está na rotina de backup
- [ ] EXIF removido do arquivo salvo
- [ ] Nome do arquivo salvo é UUID, não o nome original
