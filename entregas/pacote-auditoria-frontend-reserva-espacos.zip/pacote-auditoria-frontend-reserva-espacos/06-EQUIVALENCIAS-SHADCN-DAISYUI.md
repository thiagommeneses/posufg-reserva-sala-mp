# Anexo 06 — Tradução: shadcn/ui + React → DaisyUI + HTMX + Django Templates

O pedido lista componentes shadcn/ui e uma arquitetura React. Este anexo traduz cada item para o que existe (ou o que precisa ser construído) nesta aplicação.

**Regra geral:** shadcn/ui é *copy-paste de componentes React com Radix + Tailwind*. DaisyUI é *biblioteca de classes CSS* — não tem JavaScript de comportamento. Onde shadcn entrega interatividade pronta, aqui entra **HTMX** (servidor) ou **CSS puro** (`details`, `checkbox` hack, `<dialog>` nativo).

---

## Mapa de componentes

| shadcn/ui | Equivalente aqui | Situação | Observação |
|---|---|---|---|
| `Card` | `.surface` (classe própria em `source.css`) | ✅ existe e é usado | Já é o "Card" do sistema. Não criar outro |
| `Button` | `btn`, `btn-primary`, `btn-outline`, `btn-ghost`, `btn-sm`, `btn-xs` | ✅ existe | |
| `Badge` | `badge`, `badge-outline`, `badge-ghost`, `badge-sm` | ✅ existe | |
| `Input` | `input input-bordered`, `input-error` | ✅ existe | |
| `Textarea` | `textarea textarea-bordered` | ✅ existe | |
| `Select` | `select select-bordered` | ✅ existe | usado em admin/reservas e manutenção |
| `Checkbox` | `checkbox checkbox-sm` | ✅ existe | |
| `Separator` | `border-t border-base-300` | ✅ existe (utilitário) | |
| `Alert` | `.notice` + `.notice-error/success/warning` | ✅ existe | classes próprias |
| `Sheet` (mobile) | `drawer` do DaisyUI | ✅ existe | já é a sidebar mobile (`drawer lg:drawer-open`) |
| `Sidebar` | `drawer-side` + `.sidebar-link` | ✅ existe | duas variantes: usuário e admin |
| `Tabs` | links `?tab=` com `border-b-2` | ⚠️ improvisado | em "Minhas Reservas". DaisyUI tem `tabs`/`tab-bordered`, mas hoje não é usado |
| `Skeleton` | `skeleton` (DaisyUI) | ⚠️ existe na lib, **não usado** | hoje o loading é `.htmx-indicator` + `loading-spinner` |
| `Tooltip` | `tooltip` (DaisyUI, via `data-tip`) | ⚠️ existe na lib, **não usado** | CSS puro, sem JS |
| `DropdownMenu` | `dropdown` (DaisyUI) | ⚠️ existe na lib, **não usado** | CSS puro (focus/`details`) |
| `Popover` | `dropdown` (DaisyUI) | ⚠️ mesmo caso | não há Popover posicionado dinamicamente sem JS |
| `Dialog` / `Modal` | `modal` (DaisyUI) ou `<dialog>` nativo | ❌ **não existe nenhuma modal no sistema** | hoje confirmação é `hx-confirm` = `confirm()` do browser |
| `Command` (⌘K) | — | ❌ **não tem equivalente** | teria que ser construído: `input` + `hx-get` com debounce (`hx-trigger="keyup changed delay:300ms"`) devolvendo `<li>`s. Navegação por teclado exigiria JS |
| `Calendar` / `DatePicker` | `<input type="date">` nativo | ⚠️ nativo do browser | aparência varia entre Chrome/Edge/Firefox. Um date picker consistente exige biblioteca JS — **decisão nova** |
| `Form` (react-hook-form + zod) | `django.forms` (ModelForm) | ✅ equivalente conceitual | validação **no servidor**; erro volta renderizado |
| `Toast` / `Sonner` | `partials/_messages.html` (Django messages) | ✅ existe | |
| `Avatar` | — | ❌ não existe | não há foto de usuário no modelo |
| `Accordion` / `Collapsible` | `collapse` (DaisyUI) ou `<details>` | ⚠️ existe na lib, não usado | |
| `Table` | `table` (DaisyUI) | ✅ existe | usado em todo o admin |
| `Pagination` | paginação do Django (`paginate_by`) | ✅ existe | só em admin/reservas |
| `Progress` / `Spinner` | `loading loading-spinner loading-sm` | ✅ existe | sempre acoplado a `.htmx-indicator` |

---

## Arquitetura: o que substitui o quê

| Conceito React | Equivalente Django + HTMX |
|---|---|
| Componente com props | `{% include "partials/x.html" with prop=valor %}` |
| Composição / children | `{% block %}` + `{% extends %}` |
| `useState` local | não existe — o estado vive na **URL** (querystring) ou na sessão |
| `useEffect` + `fetch` | `hx-get` / `hx-post` com `hx-trigger` |
| Estado global (Redux/Zustand/Context) | não existe e não é necessário |
| React Query / SWR | não existe — o servidor devolve HTML já renderizado |
| Client-side routing | rotas do Django (`config/urls.py`) |
| Re-render parcial | `HX-Request` → a view devolve o **fragmento** em vez da página |
| `key` em listas | `{% for %}` — não há reconciliação |
| Suspense / loading boundary | `hx-indicator` + classe `htmx-request` |
| Error boundary | `try/except` na view → renderiza `.notice-error` |
| `onClick` handler | `hx-post` / `<form method="post">` |
| Debounce em busca | `hx-trigger="keyup changed delay:300ms"` |
| Otimistic UI | não existe — o servidor confirma antes de a UI mudar |

**O padrão central, que o redesign precisa preservar:**

```python
def get_template_names(self):
    if self.request.headers.get("HX-Request") == "true":
        return ["spaces/_space_list_results.html"]   # fragmento
    return [self.template_name]                       # página inteira
```

Toda tela com filtro segue isso. É o que substitui o "re-render do componente".

---

## Design tokens

Vocês pediram tokens centralizados em `:root`. Aqui isso já existe — mas via **tema DaisyUI**, não `:root` direto.

```css
/* assets/css/source.css */
@plugin "daisyui/theme" {
  name: "mpgo";
  --color-primary: #cd2340;
  --color-base-content: #231f20;
  --radius-box: 0.5rem;
  ...
}
```

O DaisyUI expõe esses valores como variáveis CSS reais, então:

| Vocês queriam | Aqui é |
|---|---|
| `--primary` | `--color-primary` → classe `text-primary`, `bg-primary`, `border-primary` |
| `--primary-foreground` | `--color-primary-content` → `text-primary-content` |
| `--secondary` | `--color-secondary` |
| `--muted` | `--color-base-200` / `--color-base-300` |
| `--border` | `--color-base-300` |
| `--radius` | `--radius-box`, `--radius-field`, `--radius-selector` |

**O que falta criar** (concordamos com a crítica de vocês):

```css
/* dentro do bloco @plugin "daisyui/theme" ou logo abaixo, em :root */
--brand-primary-hover:  color-mix(in oklab, var(--color-primary) 10%, white);
--brand-primary-subtle: color-mix(in oklab, var(--color-primary)  6%, white);
```

Hoje esses dois `color-mix` aparecem **repetidos em 4 seletores** (`.nav-link-active`, `.nav-link-active:hover`, `.sidebar-link-active`, `.sidebar-link-active:hover`). Devem virar token.

**O que NÃO acontece hoje e não pode passar a acontecer:** não existe **nenhum** `bg-[#cd2340]`, `text-[#cd2340]` ou hex arbitrário em template no projeto inteiro. Todos os usos passam pelo tema. Mantenham assim.

---

## Se vocês entregarem componentes React mesmo assim

Cenário provável: o mockup foi feito pensando em React e o agente de IA pode gerar `.tsx`. **Isso não é aproveitável aqui** — não há build, não há Node no runtime, não há hidratação.

Formato de entrega que **funciona**:

1. **Templates Django** (`.html`) usando classes DaisyUI/Tailwind e os partials existentes.
2. **Adições ao `assets/css/source.css`** quando uma classe própria for necessária (no padrão de `.surface`).
3. **Atributos HTMX** (`hx-get`, `hx-target`, `hx-trigger`, `hx-indicator`) para interatividade.
4. Quando um comportamento realmente exigir JS (drag-and-drop, date picker custom), **isolar num arquivo em `static/js/`** e justificar — hoje o projeto tem ~15 linhas de JS no total e essa é uma qualidade a preservar.

Formato que **não** funciona: `.tsx`, `.jsx`, `components.json`, `tailwind.config.js`, imports de `@/components/ui/*`.

---

## Regra de ouro para o prompt do agente de IA

Se vocês forem gerar os prompts por etapa (item 24.9 do pedido), o cabeçalho de cada um precisa dizer, literalmente:

```
Esta é uma aplicação Django 5.2 server-rendered.
Frontend = Django Templates + HTMX 2 + Tailwind CSS v4 + DaisyUI (tema "mpgo").

NÃO existe React, Next.js, shadcn/ui, TypeScript, Node.js ou bundler.
NÃO crie arquivos .tsx, .jsx, components.json ou tailwind.config.js.
NÃO reescreva a arquitetura. NÃO remova regras de negócio.
NÃO substitua endpoints. NÃO troque HTMX por fetch/JS.
NÃO renomeie ids usados como alvo de HTMX.
NÃO escreva cores em hex nos templates — use os tokens do tema "mpgo".

Regras de negócio ficam em reservations/validators.py e são fonte única.
As views devolvem página inteira OU fragmento, conforme o header HX-Request.
```
