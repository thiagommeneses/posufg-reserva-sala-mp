"""Admin dashboard app."""
