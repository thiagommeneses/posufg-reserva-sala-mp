"""Core application migrations."""
