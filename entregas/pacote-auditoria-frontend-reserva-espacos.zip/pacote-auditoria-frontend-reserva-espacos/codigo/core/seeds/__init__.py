"""Core seed modules."""
