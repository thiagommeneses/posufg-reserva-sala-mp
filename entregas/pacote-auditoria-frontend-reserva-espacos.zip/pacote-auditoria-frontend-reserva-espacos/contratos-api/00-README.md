# Contratos de API — exemplos de resposta

Item 7 do pedido. Os JSONs foram construídos a partir dos serializers e views reais (`spaces/serializers.py`, `reservations/serializers.py`, `ai_assistant/serializers.py`) com os dados que `make seed` cria. Os IDs e timestamps são ilustrativos; **a forma dos objetos é fiel ao código.**

> ⚠️ Cada arquivo tem uma chave `_meta` (contexto) e uma `_atencao` (armadilhas). O `_meta` e o `_atencao` **não** fazem parte da resposta real da API — são notas para vocês.

| Arquivo | Endpoint |
|---|---|
| `01-GET-spaces.json` | `GET /api/v1/spaces/` |
| `03-GET-space-availability.json` | `GET /api/v1/spaces/{id}/availability/?date=` |
| `04-GET-reservations.json` | `GET /api/v1/reservations/` |
| `05-POST-reservations.json` | `POST /api/v1/reservations/` (+ todos os erros 400) |
| `06-POST-ai-room-search.json` | `POST /api/v1/ai/room-search/` |
| `07-POST-ai-maintenance-classify.json` | `POST /api/v1/ai/maintenance-classify/` |
| `08-GET-admin-occupancy.json` | `GET /api/v1/admin/occupancy/?date=` |
| `09-POST-ai-document-qa.json` | `POST /api/v1/ai/document-qa/` |

`GET /api/v1/spaces/{id}/` devolve um único objeto no mesmo formato do array em `01`.

---

## Antes de usar isto como base do redesign, leia

**1. A interface web NÃO consome esta API.**
As telas Django consultam o ORM diretamente e devolvem HTML. A API existe para integrações e para o fluxo de QR Code. Se o redesign for feito em templates (que é a decisão), estes contratos são **referência do modelo de dados**, não o canal de dados da tela.

**2. Não há paginação nas listas.**
`REST_FRAMEWORK` não define `DEFAULT_PAGINATION_CLASS`. `GET /spaces/` e `GET /reservations/` devolvem **array puro**, sem `count`/`next`/`previous`. Com poucas dezenas de registros isso é aceitável; se a lista crescer, é mudança de contrato.

**3. Autenticação é por sessão.**
Não há token. Um cliente externo precisaria do cookie de sessão. Não existe emissão de JWT.

**4. Campos que o mockup pressupõe e que não existem em lugar nenhum:**

| Campo do mockup | Existe? |
|---|---|
| foto / capa / galeria do espaço | ❌ |
| tipo do espaço (Sala / Auditório / Compartilhado) | ❌ |
| status de disponibilidade no card | ❌ (só via endpoint separado, e por data) |
| título / finalidade da reserva | ❌ |
| nº de participantes | ❌ |
| departamento do usuário | ❌ |
| nome completo do usuário | ❌ (campo existe, nunca é preenchido) |
| aprovação / status pendente | ❌ |

**5. Documentação viva.**
Com a aplicação rodando: `http://localhost:8000/swagger/` e `/redoc/` (drf-yasg). É a fonte mais atual, gerada do próprio código.
