# Screenshots — o que capturar e como nomear

Esta pasta está **vazia de imagens de propósito**. A descrição estrutural de cada tela já está em `../03-MAPA-DE-TELAS.md`; aqui fica a lista do que precisa ser fotografado e com que nome, para que o documento e as imagens casem.

**Onde salvar:** os arquivos vão nesta mesma pasta (`screenshots/`), com exatamente os nomes da tabela abaixo. Nada de subpasta.

---

## Preparação (5 minutos)

```bash
docker compose up -d          # sobe Django + PostgreSQL
docker compose exec web python manage.py migrate
docker compose exec web python manage.py seed_data     # ou: make seed
# aplicação em http://localhost:8000
```

**Contas criadas pelo seed** (senha padrão `reserva123`):

| Usuário | Perfil |
|---|---|
| `admin` | administrador (`is_staff`) |
| `maria.silva` | usuária comum |
| `joao.santos` | usuário comum |
| `ana.costa` | usuária comum |

O seed também cria 5 espaços, 7 equipamentos, 4 reservas em status variados (inclusive uma com janela de check-in aberta hoje) e 2 bloqueios de manutenção — ou seja, **dá para capturar todos os estados sem preparar dado à mão**.

## Como capturar

- **Resolução desktop:** janela de **1440×900**, zoom do browser em **100%**, página inteira (full page).
  No Chrome/Edge: `F12` → `Ctrl+Shift+M` → definir 1440×900 → `Ctrl+Shift+P` → "Capture full size screenshot".
- **Resolução mobile:** **390×844** (iPhone 14 / referência comum), também full page.
- **Formato:** PNG.
- **Não** capturar a barra do browser, abas ou favoritos — só o viewport.
- **Não** anonimizar: os dados são de seed, fictícios.

---

## Lista de capturas

### Obrigatórias — desktop 1440×900

| Arquivo | URL | Logar como | O que garantir no enquadramento |
|---|---|---|---|
| `01-login.png` | `/accounts/login/` | — (deslogado) | tela limpa, sem erro |
| `02-registro.png` | `/accounts/register/` | — | os 4 campos visíveis |
| `03-espacos-busca.png` | `/spaces/` | `maria.silva` | ⭐ **é a tela do mockup**. Busca IA + filtros + 5 cards |
| `04-espaco-detalhe.png` | `/spaces/4/` | `maria.silva` | Sala Alfa: stepper + dados + grade de horários com **os 3 estados** (livre/reservado/manutenção). Escolha a data que tem reserva e manutenção |
| `05-nova-reserva.png` | `/spaces/4/` → clicar num slot livre | `maria.silva` | stepper no passo 3 + resumo do espaço + form de 3 campos |
| `06-minhas-reservas.png` | `/reservations/` | `maria.silva` | aba **Ativas** com os contadores das 3 abas visíveis |
| `07-reserva-detalhe.png` | `/reservations/{id}/` | `maria.silva` | a reserva com janela de check-in aberta — assim os **3 botões** (check-in, reagendar, cancelar) aparecem juntos |
| `08-reserva-reagendar.png` | `/reservations/{id}/reschedule/` | `maria.silva` | form pré-preenchido |
| `09-assistente-normas.png` | `/assistente/` | `maria.silva` | **faça uma pergunta antes** para haver resposta + fontes + histórico na lateral |
| `10-admin-dashboard.png` | `/admin-dashboard/` | `admin` | 4 KPIs + grade de ocupação |
| `11-admin-espacos-lista.png` | `/admin-dashboard/spaces/` | `admin` | tabela com badges de atributo e status |
| `12-admin-espaco-form.png` | `/admin-dashboard/spaces/4/` | `admin` | form de edição com os chips de atributos |
| `13-admin-reservas.png` | `/admin-dashboard/reservations/` | `admin` | bloco de filtros (5 campos) + tabela |
| `14-admin-manutencao-lista.png` | `/admin-dashboard/maintenance/` | `admin` | os 2 bloqueios do seed |
| `15-admin-manutencao-form.png` | `/admin-dashboard/maintenance/new/` | `admin` | **clique em classificar com IA antes**, para a sugestão aparecer |
| `16-admin-usuarios.png` | `/admin-dashboard/users/` | `admin` | os 4 usuários do seed |

### Obrigatórias — mobile 390×844

| Arquivo | URL | O que garantir |
|---|---|---|
| `20-mobile-espacos-busca.png` | `/spaces/` | header com hambúrguer, cards em 1 coluna |
| `21-mobile-sidebar-aberta.png` | `/spaces/` + hambúrguer | a gaveta sobreposta com o overlay |
| `22-mobile-espaco-detalhe.png` | `/spaces/4/` | grade de horários em 1–2 colunas |
| `23-mobile-minhas-reservas.png` | `/reservations/` | tabs + cards empilhados |

### Estados especiais — desktop 1440×900

São os que mais faltam num redesign e os que mais dão trabalho de reproduzir depois. Vale o esforço agora.

| Arquivo | Como reproduzir |
|---|---|
| `30-estado-vazio-espacos.png` | `/spaces/?min_capacity=999` → `.notice` "Nenhum espaço encontrado..." |
| `31-estado-vazio-reservas.png` | logar com `ana.costa` (sem reservas) → `/reservations/` |
| `32-estado-erro-ia.png` | apagar `GROQ_API_KEY` do `.env`, reiniciar, buscar com IA → faixa `.notice-error` |
| `33-estado-sucesso-ia.png` | buscar "sala para 8 pessoas com projetor" → faixa "Entendi: ..." + resultados |
| `34-estado-erro-conflito.png` | tentar reservar um horário já ocupado → mensagem de conflito (⚠️ hoje aparece **em inglês** — capturar assim mesmo, é o bug que o redesign vai corrigir) |
| `35-estado-loading.png` | disparar um filtro e capturar com o spinner visível (dica: `Ctrl+Shift+P` → "Show Network conditions" → throttling "Slow 3G") |
| `36-login-erro.png` | senha errada → toast + campos com `input-error` |
| `37-sem-horarios.png` | data com o dia todo ocupado → "Não há horários disponíveis para esta data." |

---

## Total: 16 desktop + 4 mobile + 8 estados = **28 capturas**

Se o tempo apertar, o mínimo indispensável para o redesign não inventar tela é:
`03`, `04`, `05`, `06`, `07`, `10`, `12`, `20`, `30`, `34`.
